import Cocoa
import FinderSync

/// 自定义脚本管理器，提供用户自定义脚本和工作流功能
class CustomScriptManager: ModuleManager {
    
    // MARK: - Properties
    
    var moduleTitle: String {
        return "自定义脚本"
    }
    
    // 用户自定义脚本
    private var userScripts: [UserScript] {
        guard let data = UserDefaults.shared.data(forKey: "UserScripts"),
              let scripts = try? JSONDecoder().decode([UserScript].self, from: data) else {
            // 返回示例脚本
            return sampleScripts
        }
        return scripts
    }
    
    // 示例脚本
    private let sampleScripts: [UserScript] = [
        UserScript(
            id: "rename_files",
            name: "批量重命名",
            description: "批量重命名选中的文件",
            iconName: "pencil",
            scriptType: .shell,
            content: "#!/bin/bash\n# 批量重命名示例脚本\nfor file in \"$@\"; do\n  mv \"$file\" \"${file%.*}_renamed.${file##*.}\"\ndone",
            applicableTypes: [.any],
            isEnabled: true
        ),
        UserScript(
            id: "image_resize",
            name: "调整图片尺寸到800px",
            description: "将选中的图片调整为宽度800像素",
            iconName: "photo",
            scriptType: .applescript,
            content: "tell application \"Image Events\"\n  repeat with i from 1 to count of arguments\n    set imgFile to POSIX file (item i of arguments)\n    open imgFile\n    scale to size 800\n    save\n    close\n  end repeat\nend tell",
            applicableTypes: [.image],
            isEnabled: true
        ),
        UserScript(
            id: "create_zip",
            name: "创建加密ZIP",
            description: "创建一个加密的ZIP文件",
            iconName: "folder.badge.gearshape",
            scriptType: .shell,
            content: "#!/bin/bash\n# 创建加密ZIP文件\nzip -e -r \"$1.zip\" \"$@\"",
            applicableTypes: [.any],
            isEnabled: true
        )
    ]
    
    // 自动化工作流
    private var automationWorkflows: [AutomationWorkflow] {
        guard let data = UserDefaults.shared.data(forKey: "AutomationWorkflows"),
              let workflows = try? JSONDecoder().decode([AutomationWorkflow].self, from: data) else {
            // 返回示例工作流
            return sampleWorkflows
        }
        return workflows
    }
    
    // 示例工作流
    private let sampleWorkflows: [AutomationWorkflow] = [
        AutomationWorkflow(
            id: "image_process",
            name: "图片处理流程",
            description: "调整图片尺寸并转换为JPG",
            iconName: "photo.stack",
            steps: [
                WorkflowStep(name: "调整尺寸", action: "resize_image", parameters: ["width": "1200", "height": "auto"]),
                WorkflowStep(name: "转换格式", action: "convert_format", parameters: ["format": "jpg", "quality": "85"])
            ],
            applicableTypes: [.image],
            isEnabled: true
        ),
        AutomationWorkflow(
            id: "backup_files",
            name: "文件备份",
            description: "压缩并备份到云端",
            iconName: "arrow.clockwise.icloud",
            steps: [
                WorkflowStep(name: "压缩文件", action: "create_zip", parameters: [:]),
                WorkflowStep(name: "上传云端", action: "upload_cloud", parameters: ["service": "icloud", "folder": "备份"])
            ],
            applicableTypes: [.any],
            isEnabled: true
        )
    ]
    
    // MARK: - ModuleManager Protocol
    
    func isApplicable(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> Bool {
        // 如果有启用的脚本或工作流，则显示该模块
        let scripts = userScripts.filter { $0.isEnabled }
        let workflows = automationWorkflows.filter { $0.isEnabled }
        
        return !scripts.isEmpty || !workflows.isEmpty
    }
    
    func menuItems(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 仅处理选中项目的菜单
        if menuKind == .contextualMenuForItems {
            // 添加自定义脚本菜单
            let scriptItems = scriptMenuItems(for: items, fileTypes: fileTypes)
            if !scriptItems.isEmpty {
                let scriptMenu = NSMenu(title: "自定义脚本")
                
                for item in scriptItems {
                    scriptMenu.addItem(item)
                }
                
                let scriptMenuItem = NSMenuItem(title: "自定义脚本", action: nil, keyEquivalent: "")
                scriptMenuItem.submenu = scriptMenu
                menuItems.append(scriptMenuItem)
            }
            
            // 添加自动化工作流菜单
            let workflowItems = workflowMenuItems(for: items, fileTypes: fileTypes)
            if !workflowItems.isEmpty {
                let workflowMenu = NSMenu(title: "自动化工作流")
                
                for item in workflowItems {
                    workflowMenu.addItem(item)
                }
                
                let workflowMenuItem = NSMenuItem(title: "自动化工作流", action: nil, keyEquivalent: "")
                workflowMenuItem.submenu = workflowMenu
                menuItems.append(workflowMenuItem)
            }
            
            // 添加创建/管理脚本菜单项
            let managementItem = NSMenuItem(title: "管理自定义脚本...", action: #selector(manageCustomScripts(_:)), keyEquivalent: "")
            managementItem.target = self
            menuItems.append(managementItem)
        }
        
        return menuItems
    }
    
    // MARK: - Menu Building Methods
    
    /// 创建脚本菜单项
    private func scriptMenuItems(for items: [URL], fileTypes: [FileType]) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 获取启用的脚本
        let scripts = userScripts.filter { $0.isEnabled }
        
        // 筛选出适用于当前文件类型的脚本
        for script in scripts {
            if script.isApplicable(for: fileTypes) {
                let item = NSMenuItem(title: script.name, action: #selector(executeScript(_:)), keyEquivalent: "")
                item.target = self
                if !script.description.isEmpty {
                    item.toolTip = script.description
                }
                if let iconName = script.iconName, let image = NSImage(systemSymbolName: iconName, accessibilityDescription: nil) {
                    item.image = image
                }
                item.representedObject = ["script": script, "items": items]
                menuItems.append(item)
            }
        }
        
        return menuItems
    }
    
    /// 创建工作流菜单项
    private func workflowMenuItems(for items: [URL], fileTypes: [FileType]) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 获取启用的工作流
        let workflows = automationWorkflows.filter { $0.isEnabled }
        
        // 筛选出适用于当前文件类型的工作流
        for workflow in workflows {
            if workflow.isApplicable(for: fileTypes) {
                let item = NSMenuItem(title: workflow.name, action: #selector(executeWorkflow(_:)), keyEquivalent: "")
                item.target = self
                if !workflow.description.isEmpty {
                    item.toolTip = workflow.description
                }
                if let iconName = workflow.iconName, let image = NSImage(systemSymbolName: iconName, accessibilityDescription: nil) {
                    item.image = image
                }
                item.representedObject = ["workflow": workflow, "items": items]
                menuItems.append(item)
            }
        }
        
        return menuItems
    }
    
    // MARK: - Action Methods
    
    @objc private func executeScript(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let script = info["script"] as? UserScript,
              let items = info["items"] as? [URL] else {
            return
        }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let scriptId = script.id
        let url = URL(string: "macrightplus://execute-script?script=\(scriptId)&paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func executeWorkflow(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let workflow = info["workflow"] as? AutomationWorkflow,
              let items = info["items"] as? [URL] else {
            return
        }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let workflowId = workflow.id
        let url = URL(string: "macrightplus://execute-workflow?workflow=\(workflowId)&paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func manageCustomScripts(_ sender: NSMenuItem) {
        let url = URL(string: "macrightplus://manage-scripts")!
        NSWorkspace.shared.open(url)
    }
    
    // MARK: - Helper Methods
    
    /// 显示提示对话框
    private func showAlert(title: String, message: String) {
        // 在Finder扩展中不能直接显示警告，需要通知主应用
        let encodedMessage = message.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? message
        let encodedTitle = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? title
        let url = URL(string: "macrightplus://show-alert?title=\(encodedTitle)&message=\(encodedMessage)")!
        NSWorkspace.shared.open(url)
    }
}

/// 文件类型枚举扩展，用于脚本适用性判断
enum ScriptApplicableType: String, Codable {
    case any = "any"
    case image = "image"
    case audio = "audio"
    case video = "video"
    case document = "document"
    case code = "code"
    case archive = "archive"
    case directory = "directory"
    
    /// 检查是否适用于指定的文件类型
    func isApplicable(for fileType: FileType) -> Bool {
        switch self {
        case .any:
            return true
        case .image:
            return fileType == .image
        case .audio:
            return fileType == .audio
        case .video:
            return fileType == .video
        case .document:
            return fileType == .document
        case .code:
            return fileType == .code
        case .archive:
            return fileType == .archive
        case .directory:
            return fileType == .directory
        }
    }
}

/// 脚本类型枚举
enum ScriptType: String, Codable {
    case shell = "shell"
    case applescript = "applescript"
    case javascript = "javascript"
    case python = "python"
    case ruby = "ruby"
}

/// 用户自定义脚本结构
struct UserScript: Codable {
    let id: String
    let name: String
    let description: String
    let iconName: String?
    let scriptType: ScriptType
    let content: String
    let applicableTypes: [ScriptApplicableType]
    let isEnabled: Bool
    
    /// 检查脚本是否适用于指定的文件类型
    func isApplicable(for fileTypes: [FileType]) -> Bool {
        // 如果脚本适用于任何类型，直接返回true
        if applicableTypes.contains(.any) {
            return true
        }
        
        // 检查是否有任何适用的文件类型
        for fileType in fileTypes {
            for applicableType in applicableTypes {
                if applicableType.isApplicable(for: fileType) {
                    return true
                }
            }
        }
        
        return false
    }
}

/// 工作流步骤结构
struct WorkflowStep: Codable {
    let name: String
    let action: String
    let parameters: [String: String]
}

/// 自动化工作流结构
struct AutomationWorkflow: Codable {
    let id: String
    let name: String
    let description: String
    let iconName: String?
    let steps: [WorkflowStep]
    let applicableTypes: [ScriptApplicableType]
    let isEnabled: Bool
    
    /// 检查工作流是否适用于指定的文件类型
    func isApplicable(for fileTypes: [FileType]) -> Bool {
        // 如果工作流适用于任何类型，直接返回true
        if applicableTypes.contains(.any) {
            return true
        }
        
        // 检查是否有任何适用的文件类型
        for fileType in fileTypes {
            for applicableType in applicableTypes {
                if applicableType.isApplicable(for: fileType) {
                    return true
                }
            }
        }
        
        return false
    }
} 
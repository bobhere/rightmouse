import Cocoa
import FinderSync

/// 开发者工具管理器，提供终端、编辑器和Git等开发工具的快捷操作
class DeveloperToolsManager: ModuleManager {
    
    // MARK: - Properties
    
    var moduleTitle: String {
        return "开发工具"
    }
    
    // 支持的终端应用
    private let supportedTerminals: [(name: String, identifier: String, icon: String)] = [
        ("终端", "com.apple.Terminal", "terminal"),
        ("iTerm2", "com.googlecode.iterm2", "terminal.fill"),
        ("Warp", "dev.warp.Warp-Stable", "bolt.square"),
        ("Hyper", "co.zeit.hyper", "square.grid.3x2"),
        ("Tabby", "org.tabby", "square.grid.2x2")
    ]
    
    // 支持的代码编辑器
    private let supportedEditors: [(name: String, identifier: String, icon: String)] = [
        ("VSCode", "com.microsoft.VSCode", "chevron.left.forwardslash.chevron.right"),
        ("Sublime Text", "com.sublimetext.4", "doc.text"),
        ("Xcode", "com.apple.dt.Xcode", "hammer"),
        ("JetBrains IDEA", "com.jetbrains.intellij", "curlybraces"),
        ("PyCharm", "com.jetbrains.pycharm", "p.square"),
        ("WebStorm", "com.jetbrains.WebStorm", "w.square"),
        ("GoLand", "com.jetbrains.goland", "g.square"),
        ("CLion", "com.jetbrains.CLion", "c.square")
    ]
    
    // MARK: - ModuleManager Protocol
    
    func isApplicable(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> Bool {
        // 如果是选中了代码文件，或者是在目录上右键，则显示开发者工具菜单
        if menuKind == .contextualMenuForContainer {
            return true
        }
        
        // 检查是否选中了代码文件或目录
        for fileType in fileTypes {
            if fileType == .code || fileType == .directory {
                return true
            }
        }
        
        // 检查是否是项目目录（包含.git等特征）
        if items.count == 1 && fileTypes[0] == .directory {
            let url = items[0]
            let gitDirURL = url.appendingPathComponent(".git")
            if FileManager.default.fileExists(atPath: gitDirURL.path) {
                return true
            }
            
            // 检查是否包含常见项目文件
            let projectFiles = ["package.json", "Cargo.toml", "Gemfile", "go.mod", "pom.xml", "build.gradle"]
            for projectFile in projectFiles {
                let fileURL = url.appendingPathComponent(projectFile)
                if FileManager.default.fileExists(atPath: fileURL.path) {
                    return true
                }
            }
        }
        
        return false
    }
    
    func menuItems(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 获取目标URL
        let targetURL: URL
        if menuKind == .contextualMenuForContainer {
            guard let url = FIFinderSyncController.default().targetedURL() else {
                return []
            }
            targetURL = url
        } else if items.count == 1 {
            targetURL = items[0]
        } else {
            // 对于多选，我们不提供开发者工具菜单
            return []
        }
        
        // 添加终端菜单组
        menuItems.append(terminalMenu(for: targetURL))
        
        // 添加编辑器菜单组
        menuItems.append(editorMenu(for: targetURL))
        
        // 如果是Git仓库，添加Git菜单组
        if isGitRepository(at: targetURL) {
            menuItems.append(gitMenu(for: targetURL))
        }
        
        return menuItems
    }
    
    // MARK: - Menu Building Methods
    
    /// 创建终端子菜单
    private func terminalMenu(for url: URL) -> NSMenuItem {
        let menu = NSMenu(title: "在终端中打开")
        
        // 获取已安装的终端应用
        let installedTerminals = supportedTerminals.filter { appInfo in
            return NSWorkspace.shared.urlForApplication(withBundleIdentifier: appInfo.identifier) != nil
        }
        
        // 如果没有找到已安装的终端应用，只添加系统自带的终端
        if installedTerminals.isEmpty {
            let terminalItem = NSMenuItem(title: "终端", action: #selector(openInTerminal(_:)), keyEquivalent: "")
            terminalItem.target = self
            terminalItem.representedObject = ["url": url, "identifier": "com.apple.Terminal"]
            menu.addItem(terminalItem)
        } else {
            // 添加已安装的终端应用
            for terminal in installedTerminals {
                let item = NSMenuItem(title: terminal.name, action: #selector(openInTerminal(_:)), keyEquivalent: "")
                item.target = self
                if let image = NSImage(systemSymbolName: terminal.icon, accessibilityDescription: nil) {
                    item.image = image
                }
                item.representedObject = ["url": url, "identifier": terminal.identifier]
                menu.addItem(item)
            }
        }
        
        let menuItem = NSMenuItem(title: "在终端中打开", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建编辑器子菜单
    private func editorMenu(for url: URL) -> NSMenuItem {
        let menu = NSMenu(title: "用编辑器打开")
        
        // 获取已安装的编辑器应用
        let installedEditors = supportedEditors.filter { appInfo in
            return NSWorkspace.shared.urlForApplication(withBundleIdentifier: appInfo.identifier) != nil
        }
        
        if installedEditors.isEmpty {
            // 如果没有找到已安装的编辑器，添加默认打开选项
            let defaultItem = NSMenuItem(title: "默认编辑器", action: #selector(openWithDefaultEditor(_:)), keyEquivalent: "")
            defaultItem.target = self
            defaultItem.representedObject = url
            menu.addItem(defaultItem)
        } else {
            // 添加已安装的编辑器应用
            for editor in installedEditors {
                let item = NSMenuItem(title: editor.name, action: #selector(openInEditor(_:)), keyEquivalent: "")
                item.target = self
                if let image = NSImage(systemSymbolName: editor.icon, accessibilityDescription: nil) {
                    item.image = image
                }
                item.representedObject = ["url": url, "identifier": editor.identifier]
                menu.addItem(item)
            }
        }
        
        let menuItem = NSMenuItem(title: "用编辑器打开", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建Git子菜单
    private func gitMenu(for url: URL) -> NSMenuItem {
        let menu = NSMenu(title: "Git操作")
        
        // 检查是否是Git仓库根目录或子目录
        let isRoot = isGitRepositoryRoot(at: url)
        
        // 基本Git操作
        if !isRoot {
            // 当前目录不是仓库根目录时显示此选项
            let rootItem = NSMenuItem(title: "在仓库根目录打开终端", action: #selector(openTerminalAtGitRoot(_:)), keyEquivalent: "")
            rootItem.target = self
            rootItem.representedObject = url
            menu.addItem(rootItem)
            menu.addItem(NSMenuItem.separator())
        }
        
        // 状态操作
        let statusItem = NSMenuItem(title: "查看状态", action: #selector(gitStatus(_:)), keyEquivalent: "")
        statusItem.target = self
        statusItem.representedObject = url
        menu.addItem(statusItem)
        
        let logItem = NSMenuItem(title: "查看日志", action: #selector(gitLog(_:)), keyEquivalent: "")
        logItem.target = self
        logItem.representedObject = url
        menu.addItem(logItem)
        
        menu.addItem(NSMenuItem.separator())
        
        // 基本操作
        let pullItem = NSMenuItem(title: "拉取(Pull)", action: #selector(gitPull(_:)), keyEquivalent: "")
        pullItem.target = self
        pullItem.representedObject = url
        menu.addItem(pullItem)
        
        let pushItem = NSMenuItem(title: "推送(Push)", action: #selector(gitPush(_:)), keyEquivalent: "")
        pushItem.target = self
        pushItem.representedObject = url
        menu.addItem(pushItem)
        
        let fetchItem = NSMenuItem(title: "获取(Fetch)", action: #selector(gitFetch(_:)), keyEquivalent: "")
        fetchItem.target = self
        fetchItem.representedObject = url
        menu.addItem(fetchItem)
        
        menu.addItem(NSMenuItem.separator())
        
        // 分支操作子菜单
        let branchSubmenu = NSMenu(title: "分支操作")
        
        let createBranchItem = NSMenuItem(title: "创建分支...", action: #selector(gitCreateBranch(_:)), keyEquivalent: "")
        createBranchItem.target = self
        createBranchItem.representedObject = url
        branchSubmenu.addItem(createBranchItem)
        
        let switchBranchItem = NSMenuItem(title: "切换分支...", action: #selector(gitSwitchBranch(_:)), keyEquivalent: "")
        switchBranchItem.target = self
        switchBranchItem.representedObject = url
        branchSubmenu.addItem(switchBranchItem)
        
        let branchItem = NSMenuItem(title: "分支操作", action: nil, keyEquivalent: "")
        branchItem.submenu = branchSubmenu
        menu.addItem(branchItem)
        
        let menuItem = NSMenuItem(title: "Git操作", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    // MARK: - Action Methods
    
    @objc private func openInTerminal(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let url = info["url"] as? URL,
              let identifier = info["identifier"] as? String else {
            return
        }
        
        // 获取应用URL
        guard let appURL = NSWorkspace.shared.urlForApplication(withBundleIdentifier: identifier) else {
            return
        }
        
        // 判断是文件还是目录
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory) else {
            return
        }
        
        // 获取要在终端中打开的路径
        let path = isDirectory.boolValue ? url.path : url.deletingLastPathComponent().path
        
        // 根据不同的终端应用使用不同的AppleScript
        var script = ""
        switch identifier {
        case "com.apple.Terminal":
            script = """
            tell application "Terminal"
                activate
                do script "cd '\(path.replacingOccurrences(of: "'", with: "'\\''"))'"
            end tell
            """
        case "com.googlecode.iterm2":
            script = """
            tell application "iTerm"
                activate
                set newWindow to (create window with default profile)
                tell current session of newWindow
                    write text "cd '\(path.replacingOccurrences(of: "'", with: "'\\''"))'"
                end tell
            end tell
            """
        default:
            // 对于其他终端，使用默认的打开方式
            NSWorkspace.shared.open([url], withApplicationAt: appURL, configuration: NSWorkspace.OpenConfiguration())
            return
        }
        
        // 执行AppleScript
        var error: NSDictionary?
        if let scriptObject = NSAppleScript(source: script) {
            scriptObject.executeAndReturnError(&error)
            if let error = error {
                NSLog("Error executing AppleScript: \(error)")
            }
        }
    }
    
    @objc private func openInEditor(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let url = info["url"] as? URL,
              let identifier = info["identifier"] as? String else {
            return
        }
        
        // 获取应用URL
        guard let appURL = NSWorkspace.shared.urlForApplication(withBundleIdentifier: identifier) else {
            return
        }
        
        // 打开文件或文件夹
        NSWorkspace.shared.open([url], withApplicationAt: appURL, configuration: NSWorkspace.OpenConfiguration())
    }
    
    @objc private func openWithDefaultEditor(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        // 用默认应用打开
        NSWorkspace.shared.open(url)
    }
    
    @objc private func openTerminalAtGitRoot(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        // 获取Git仓库根目录
        guard let rootURL = gitRepositoryRoot(for: url) else {
            return
        }
        
        // 在终端中打开根目录
        let terminalMenuItem = NSMenuItem(title: "", action: nil, keyEquivalent: "")
        terminalMenuItem.representedObject = ["url": rootURL, "identifier": "com.apple.Terminal"]
        openInTerminal(terminalMenuItem)
    }
    
    @objc private func gitStatus(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        executeGitCommand("status", at: url)
    }
    
    @objc private func gitLog(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        executeGitCommand("log --oneline -n 10", at: url)
    }
    
    @objc private func gitPull(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        executeGitCommand("pull", at: url)
    }
    
    @objc private func gitPush(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        executeGitCommand("push", at: url)
    }
    
    @objc private func gitFetch(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        executeGitCommand("fetch --all", at: url)
    }
    
    @objc private func gitCreateBranch(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        // 通知主应用打开创建分支对话框
        let escapedPath = url.path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? url.path
        let commandURL = URL(string: "macrightplus://git-create-branch?path=\(escapedPath)")!
        NSWorkspace.shared.open(commandURL)
    }
    
    @objc private func gitSwitchBranch(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        // 通知主应用打开切换分支对话框
        let escapedPath = url.path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? url.path
        let commandURL = URL(string: "macrightplus://git-switch-branch?path=\(escapedPath)")!
        NSWorkspace.shared.open(commandURL)
    }
    
    // MARK: - Helper Methods
    
    /// 执行Git命令
    private func executeGitCommand(_ command: String, at url: URL) {
        // 获取Git仓库根目录
        guard let rootURL = gitRepositoryRoot(for: url) else {
            return
        }
        
        // 构建并执行AppleScript
        let script = """
        tell application "Terminal"
            activate
            do script "cd '\(rootURL.path.replacingOccurrences(of: "'", with: "'\\''"))' && git \(command)"
        end tell
        """
        
        var error: NSDictionary?
        if let scriptObject = NSAppleScript(source: script) {
            scriptObject.executeAndReturnError(&error)
            if let error = error {
                NSLog("Error executing Git command: \(error)")
            }
        }
    }
    
    /// 检查URL是否是Git仓库
    private func isGitRepository(at url: URL) -> Bool {
        return gitRepositoryRoot(for: url) != nil
    }
    
    /// 检查URL是否是Git仓库的根目录
    private func isGitRepositoryRoot(at url: URL) -> Bool {
        let gitDirURL = url.appendingPathComponent(".git")
        return FileManager.default.fileExists(atPath: gitDirURL.path)
    }
    
    /// 获取Git仓库根目录
    private func gitRepositoryRoot(for url: URL) -> URL? {
        var currentURL = url
        
        // 如果URL是文件，获取其父目录
        var isDirectory: ObjCBool = false
        if FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory), !isDirectory.boolValue {
            currentURL = url.deletingLastPathComponent()
        }
        
        // 向上查找.git目录
        while true {
            let gitDirURL = currentURL.appendingPathComponent(".git")
            if FileManager.default.fileExists(atPath: gitDirURL.path) {
                return currentURL
            }
            
            // 已经到达文件系统根目录
            if currentURL.path == "/" {
                break
            }
            
            // 向上一级目录
            currentURL = currentURL.deletingLastPathComponent()
        }
        
        return nil
    }
} 
import Cocoa
import FinderSync

/// 文档工具管理器，提供文档格式转换、PDF处理等功能
class DocumentToolsManager: ModuleManager {
    
    // MARK: - Properties
    
    var moduleTitle: String {
        return "文档工具"
    }
    
    // 支持的文档格式
    private let supportedDocFormats = [
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", 
        "txt", "rtf", "md", "pages", "numbers", "key", "csv", "html"
    ]
    
    // MARK: - ModuleManager Protocol
    
    func isApplicable(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> Bool {
        // 检查是否选中了文档文件
        for fileType in fileTypes {
            if fileType == .document {
                return true
            }
        }
        
        // 检查文件扩展名是否是支持的文档格式
        for url in items {
            if supportedDocFormats.contains(url.pathExtension.lowercased()) {
                return true
            }
        }
        
        return false
    }
    
    func menuItems(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 仅处理选中项目的菜单
        if menuKind == .contextualMenuForItems {
            // 添加格式转换菜单
            menuItems.append(convertMenu(for: items))
            
            // 添加PDF处理菜单
            let pdfItems = items.filter { $0.pathExtension.lowercased() == "pdf" }
            if !pdfItems.isEmpty {
                menuItems.append(pdfMenu(for: pdfItems))
            }
            
            // 添加文本处理菜单
            let textItems = items.filter { 
                let ext = $0.pathExtension.lowercased()
                return ["txt", "md", "rtf", "html", "csv"].contains(ext)
            }
            if !textItems.isEmpty {
                menuItems.append(textMenu(for: textItems))
            }
        }
        
        return menuItems
    }
    
    // MARK: - Menu Building Methods
    
    /// 创建格式转换子菜单
    private func convertMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "转换格式")
        
        // 基于文件类型添加不同的转换选项
        let fileExtensions = items.map { $0.pathExtension.lowercased() }
        
        // 如果是Office文档，添加相应转换选项
        if fileExtensions.contains(where: { ["doc", "docx"].contains($0) }) {
            let pdfItem = NSMenuItem(title: "转换为PDF", action: #selector(convertToPDF(_:)), keyEquivalent: "")
            pdfItem.target = self
            pdfItem.representedObject = items
            menu.addItem(pdfItem)
            
            let txtItem = NSMenuItem(title: "转换为TXT", action: #selector(convertToTxt(_:)), keyEquivalent: "")
            txtItem.target = self
            txtItem.representedObject = items
            menu.addItem(txtItem)
        }
        
        // Excel文档转换选项
        if fileExtensions.contains(where: { ["xls", "xlsx"].contains($0) }) {
            let csvItem = NSMenuItem(title: "转换为CSV", action: #selector(convertToCSV(_:)), keyEquivalent: "")
            csvItem.target = self
            csvItem.representedObject = items
            menu.addItem(csvItem)
            
            let pdfExcelItem = NSMenuItem(title: "转换为PDF", action: #selector(convertToPDF(_:)), keyEquivalent: "")
            pdfExcelItem.target = self
            pdfExcelItem.representedObject = items
            menu.addItem(pdfExcelItem)
        }
        
        // PowerPoint文档转换选项
        if fileExtensions.contains(where: { ["ppt", "pptx"].contains($0) }) {
            let pdfPptItem = NSMenuItem(title: "转换为PDF", action: #selector(convertToPDF(_:)), keyEquivalent: "")
            pdfPptItem.target = self
            pdfPptItem.representedObject = items
            menu.addItem(pdfPptItem)
        }
        
        // 纯文本文档转换选项
        if fileExtensions.contains(where: { ["txt", "md", "rtf"].contains($0) }) {
            let htmlItem = NSMenuItem(title: "转换为HTML", action: #selector(convertToHTML(_:)), keyEquivalent: "")
            htmlItem.target = self
            htmlItem.representedObject = items
            menu.addItem(htmlItem)
            
            if fileExtensions.contains("md") {
                let pdfMarkdownItem = NSMenuItem(title: "Markdown转PDF", action: #selector(convertMarkdownToPDF(_:)), keyEquivalent: "")
                pdfMarkdownItem.target = self
                pdfMarkdownItem.representedObject = items.filter { $0.pathExtension.lowercased() == "md" }
                menu.addItem(pdfMarkdownItem)
            }
        }
        
        // PDF转换选项
        if fileExtensions.contains("pdf") {
            let pdfToTextItem = NSMenuItem(title: "PDF转文本", action: #selector(convertPDFToText(_:)), keyEquivalent: "")
            pdfToTextItem.target = self
            pdfToTextItem.representedObject = items.filter { $0.pathExtension.lowercased() == "pdf" }
            menu.addItem(pdfToTextItem)
            
            let pdfToImagesItem = NSMenuItem(title: "PDF转图片", action: #selector(convertPDFToImages(_:)), keyEquivalent: "")
            pdfToImagesItem.target = self
            pdfToImagesItem.representedObject = items.filter { $0.pathExtension.lowercased() == "pdf" }
            menu.addItem(pdfToImagesItem)
        }
        
        // 批量转换选项
        if items.count > 1 {
            menu.addItem(NSMenuItem.separator())
            
            let batchItem = NSMenuItem(title: "批量转换...", action: #selector(batchConvertDocuments(_:)), keyEquivalent: "")
            batchItem.target = self
            batchItem.representedObject = items
            menu.addItem(batchItem)
        }
        
        // 如果没有添加任何项，添加一个提示项
        if menu.items.isEmpty {
            let noItem = NSMenuItem(title: "没有可用的转换选项", action: nil, keyEquivalent: "")
            noItem.isEnabled = false
            menu.addItem(noItem)
        }
        
        let menuItem = NSMenuItem(title: "转换格式", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建PDF处理子菜单
    private func pdfMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "PDF工具")
        
        // 单个PDF文件的操作
        if items.count == 1 {
            let compressItem = NSMenuItem(title: "压缩PDF", action: #selector(compressPDF(_:)), keyEquivalent: "")
            compressItem.target = self
            compressItem.representedObject = items[0]
            menu.addItem(compressItem)
            
            let encryptItem = NSMenuItem(title: "加密PDF", action: #selector(encryptPDF(_:)), keyEquivalent: "")
            encryptItem.target = self
            encryptItem.representedObject = items[0]
            menu.addItem(encryptItem)
            
            let extractPagesItem = NSMenuItem(title: "提取页面", action: #selector(extractPDFPages(_:)), keyEquivalent: "")
            extractPagesItem.target = self
            extractPagesItem.representedObject = items[0]
            menu.addItem(extractPagesItem)
            
            let rotateItem = NSMenuItem(title: "旋转PDF", action: #selector(rotatePDF(_:)), keyEquivalent: "")
            rotateItem.target = self
            rotateItem.representedObject = items[0]
            menu.addItem(rotateItem)
            
            let extractTextItem = NSMenuItem(title: "提取文本", action: #selector(extractPDFText(_:)), keyEquivalent: "")
            extractTextItem.target = self
            extractTextItem.representedObject = items[0]
            menu.addItem(extractTextItem)
            
            let extractImagesItem = NSMenuItem(title: "提取图片", action: #selector(extractPDFImages(_:)), keyEquivalent: "")
            extractImagesItem.target = self
            extractImagesItem.representedObject = items[0]
            menu.addItem(extractImagesItem)
        }
        
        // 多个PDF文件的操作
        if items.count > 1 {
            if items.count == 1 {
                menu.addItem(NSMenuItem.separator())
            }
            
            let mergeItem = NSMenuItem(title: "合并PDF", action: #selector(mergePDFs(_:)), keyEquivalent: "")
            mergeItem.target = self
            mergeItem.representedObject = items
            menu.addItem(mergeItem)
        }
        
        let menuItem = NSMenuItem(title: "PDF工具", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建文本处理子菜单
    private func textMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "文本工具")
        
        // 单个文本文件的操作
        if items.count == 1 {
            let encodingItem = NSMenuItem(title: "转换编码", action: #selector(convertTextEncoding(_:)), keyEquivalent: "")
            encodingItem.target = self
            encodingItem.representedObject = items[0]
            menu.addItem(encodingItem)
            
            let lineEndingsItem = NSMenuItem(title: "转换行尾", action: #selector(convertLineEndings(_:)), keyEquivalent: "")
            lineEndingsItem.target = self
            lineEndingsItem.representedObject = items[0]
            menu.addItem(lineEndingsItem)
            
            let countItem = NSMenuItem(title: "统计字数", action: #selector(countWords(_:)), keyEquivalent: "")
            countItem.target = self
            countItem.representedObject = items[0]
            menu.addItem(countItem)
        }
        
        // 特定文件格式的操作
        for item in items {
            let ext = item.pathExtension.lowercased()
            
            if ext == "csv" {
                let csvItem = NSMenuItem(title: "CSV工具", action: nil, keyEquivalent: "")
                let csvSubmenu = NSMenu(title: "CSV工具")
                
                let viewItem = NSMenuItem(title: "预览CSV", action: #selector(previewCSV(_:)), keyEquivalent: "")
                viewItem.target = self
                viewItem.representedObject = item
                csvSubmenu.addItem(viewItem)
                
                let sortItem = NSMenuItem(title: "排序CSV", action: #selector(sortCSV(_:)), keyEquivalent: "")
                sortItem.target = self
                sortItem.representedObject = item
                csvSubmenu.addItem(sortItem)
                
                let filterItem = NSMenuItem(title: "筛选CSV", action: #selector(filterCSV(_:)), keyEquivalent: "")
                filterItem.target = self
                filterItem.representedObject = item
                csvSubmenu.addItem(filterItem)
                
                csvItem.submenu = csvSubmenu
                menu.addItem(csvItem)
            }
        }
        
        // 多个文本文件的操作
        if items.count > 1 {
            menu.addItem(NSMenuItem.separator())
            
            let mergeItem = NSMenuItem(title: "合并文本文件", action: #selector(mergeTextFiles(_:)), keyEquivalent: "")
            mergeItem.target = self
            mergeItem.representedObject = items
            menu.addItem(mergeItem)
        }
        
        let menuItem = NSMenuItem(title: "文本工具", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    // MARK: - Action Methods
    
    // 文档格式转换
    
    @objc private func convertToPDF(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        // 构建参数并通知主应用进行转换
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-to-pdf?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func convertToTxt(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-to-txt?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func convertToCSV(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-to-csv?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func convertToHTML(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-to-html?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func convertMarkdownToPDF(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-markdown-to-pdf?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func convertPDFToText(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-pdf-to-text?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func convertPDFToImages(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-pdf-to-images?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func batchConvertDocuments(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://batch-convert-documents?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    // PDF工具
    
    @objc private func compressPDF(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://compress-pdf?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func encryptPDF(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://encrypt-pdf?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func extractPDFPages(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://extract-pdf-pages?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func rotatePDF(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://rotate-pdf?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func extractPDFText(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://extract-pdf-text?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func extractPDFImages(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://extract-pdf-images?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func mergePDFs(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://merge-pdfs?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    // 文本工具
    
    @objc private func convertTextEncoding(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://convert-text-encoding?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func convertLineEndings(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://convert-line-endings?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func countWords(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://count-words?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func previewCSV(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://preview-csv?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func sortCSV(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://sort-csv?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func filterCSV(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://filter-csv?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func mergeTextFiles(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://merge-text-files?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    // MARK: - Helper Methods
    
    /// 显示提示对话框
    private func showAlert(title: String, message: String) {
        // 在Finder扩展中不能直接显示警告，需要通知主应用
        let encodedMessage = message.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? message
        let encodedTitle = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? title
        let url = URL(string: "macrightplus://show-alert?title=\(encodedTitle)&message=\(encodedMessage)")!
        NSWorkspace.shared.open(url)
    }
} 
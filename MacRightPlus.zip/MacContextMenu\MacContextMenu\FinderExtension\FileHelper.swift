import Cocoa

/// 文件操作辅助类
class FileHelper {
    
    /// 获取文件类型
    /// - Parameter url: 文件URL
    /// - Returns: 文件类型
    static func getFileType(for url: URL) -> FileType {
        var isDirectory: ObjCBool = false
        
        // 检查文件是否存在
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory) else {
            return .unknown
        }
        
        // 如果是目录，返回目录类型
        if isDirectory.boolValue {
            return .directory
        }
        
        // 获取文件扩展名
        guard let fileExtension = url.pathExtension.isEmpty ? nil : url.pathExtension else {
            return .unknown
        }
        
        // 根据扩展名判断文件类型
        return FileType.from(extension: fileExtension)
    }
    
    /// 获取文件大小
    /// - Parameter url: 文件URL
    /// - Returns: 文件大小（字节）
    static func getFileSize(for url: URL) -> Int64 {
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            return attributes[.size] as? Int64 ?? 0
        } catch {
            NSLog("Error getting file size: \(error)")
            return 0
        }
    }
    
    /// 获取格式化的文件大小
    /// - Parameter url: 文件URL
    /// - Returns: 格式化的文件大小字符串（如：1.2 MB）
    static func getFormattedFileSize(for url: URL) -> String {
        let fileSize = getFileSize(for: url)
        return ByteCountFormatter.string(fromByteCount: fileSize, countStyle: .file)
    }
    
    /// 获取文件创建时间
    /// - Parameter url: 文件URL
    /// - Returns: 创建时间
    static func getCreationDate(for url: URL) -> Date? {
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            return attributes[.creationDate] as? Date
        } catch {
            NSLog("Error getting creation date: \(error)")
            return nil
        }
    }
    
    /// 获取文件修改时间
    /// - Parameter url: 文件URL
    /// - Returns: 修改时间
    static func getModificationDate(for url: URL) -> Date? {
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            return attributes[.modificationDate] as? Date
        } catch {
            NSLog("Error getting modification date: \(error)")
            return nil
        }
    }
    
    /// 检查是否有读权限
    /// - Parameter url: 文件URL
    /// - Returns: 是否有读权限
    static func isReadable(url: URL) -> Bool {
        return FileManager.default.isReadableFile(atPath: url.path)
    }
    
    /// 检查是否有写权限
    /// - Parameter url: 文件URL
    /// - Returns: 是否有写权限
    static func isWritable(url: URL) -> Bool {
        return FileManager.default.isWritableFile(atPath: url.path)
    }
    
    /// 复制文件到指定目录
    /// - Parameters:
    ///   - url: 源文件URL
    ///   - targetURL: 目标目录URL
    ///   - overwrite: 是否覆盖已存在的文件
    /// - Returns: 成功返回true，失败返回false
    static func copyFile(from url: URL, to targetURL: URL, overwrite: Bool = false) -> Bool {
        let fileManager = FileManager.default
        let targetFileURL = targetURL.appendingPathComponent(url.lastPathComponent)
        
        // 如果目标文件已存在且不允许覆盖，则返回失败
        if fileManager.fileExists(atPath: targetFileURL.path) && !overwrite {
            return false
        }
        
        // 如果目标文件已存在且允许覆盖，则先删除
        if fileManager.fileExists(atPath: targetFileURL.path) && overwrite {
            do {
                try fileManager.removeItem(at: targetFileURL)
            } catch {
                NSLog("Error removing existing file: \(error)")
                return false
            }
        }
        
        // 复制文件
        do {
            try fileManager.copyItem(at: url, to: targetFileURL)
            return true
        } catch {
            NSLog("Error copying file: \(error)")
            return false
        }
    }
    
    /// 移动文件到指定目录
    /// - Parameters:
    ///   - url: 源文件URL
    ///   - targetURL: 目标目录URL
    ///   - overwrite: 是否覆盖已存在的文件
    /// - Returns: 成功返回true，失败返回false
    static func moveFile(from url: URL, to targetURL: URL, overwrite: Bool = false) -> Bool {
        let fileManager = FileManager.default
        let targetFileURL = targetURL.appendingPathComponent(url.lastPathComponent)
        
        // 如果目标文件已存在且不允许覆盖，则返回失败
        if fileManager.fileExists(atPath: targetFileURL.path) && !overwrite {
            return false
        }
        
        // 如果目标文件已存在且允许覆盖，则先删除
        if fileManager.fileExists(atPath: targetFileURL.path) && overwrite {
            do {
                try fileManager.removeItem(at: targetFileURL)
            } catch {
                NSLog("Error removing existing file: \(error)")
                return false
            }
        }
        
        // 移动文件
        do {
            try fileManager.moveItem(at: url, to: targetFileURL)
            return true
        } catch {
            NSLog("Error moving file: \(error)")
            return false
        }
    }
    
    /// 创建新文件
    /// - Parameters:
    ///   - directory: 目录URL
    ///   - fileName: 文件名
    ///   - content: 文件内容
    /// - Returns: 创建的文件URL，失败返回nil
    static func createFile(in directory: URL, named fileName: String, content: Data? = nil) -> URL? {
        let fileManager = FileManager.default
        let fileURL = directory.appendingPathComponent(fileName)
        
        // 创建文件
        let createSuccess = fileManager.createFile(
            atPath: fileURL.path,
            contents: content,
            attributes: nil
        )
        
        return createSuccess ? fileURL : nil
    }
    
    /// 计算目录大小
    /// - Parameter directoryURL: 目录URL
    /// - Returns: 目录大小（字节）
    static func calculateDirectorySize(at directoryURL: URL) -> Int64 {
        let fileManager = FileManager.default
        var size: Int64 = 0
        
        do {
            let contents = try fileManager.contentsOfDirectory(at: directoryURL, includingPropertiesForKeys: nil)
            
            for url in contents {
                var isDirectory: ObjCBool = false
                if fileManager.fileExists(atPath: url.path, isDirectory: &isDirectory) {
                    if isDirectory.boolValue {
                        size += calculateDirectorySize(at: url)
                    } else {
                        size += getFileSize(for: url)
                    }
                }
            }
        } catch {
            NSLog("Error calculating directory size: \(error)")
        }
        
        return size
    }
} 
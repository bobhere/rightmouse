import Cocoa
import FinderSync

/// 文件操作管理器，实现基本的文件操作功能
class FileOperationsManager: ModuleManager {
    
    // MARK: - Properties
    
    var moduleTitle: String {
        return "文件操作"
    }
    
    // 常用目标目录
    private var favoriteDirectories: [URL] {
        let paths = UserDefaults.shared.array(forKey: "FavoriteDirectories") as? [String] ?? []
        return paths.map { URL(fileURLWithPath: $0) }
    }
    
    // 文件模板
    private var fileTemplates: [FileTemplate] {
        // 从UserDefaults加载模板配置
        guard let templatesData = UserDefaults.shared.data(forKey: "FileTemplates") else {
            // 返回默认模板
            return defaultTemplates
        }
        
        do {
            let templates = try JSONDecoder().decode([FileTemplate].self, from: templatesData)
            return templates.isEmpty ? defaultTemplates : templates
        } catch {
            NSLog("Error decoding file templates: \(error)")
            return defaultTemplates
        }
    }
    
    // 默认文件模板
    private var defaultTemplates: [FileTemplate] {
        return [
            FileTemplate(name: "文本文件.txt", iconName: "doc.text", category: "文本", content: ""),
            FileTemplate(name: "Markdown.md", iconName: "doc.plaintext", category: "文本", content: "# 标题\n\n正文内容"),
            FileTemplate(name: "HTML文件.html", iconName: "doc.richtext", category: "网页", content: "<!DOCTYPE html>\n<html>\n<head>\n    <title>标题</title>\n    <meta charset=\"utf-8\">\n</head>\n<body>\n    <h1>Hello World</h1>\n</body>\n</html>"),
            FileTemplate(name: "Python脚本.py", iconName: "chevron.left.forwardslash.chevron.right", category: "编程", content: "#!/usr/bin/env python\n\ndef main():\n    print('Hello, World!')\n\nif __name__ == '__main__':\n    main()")
        ]
    }
    
    // MARK: - ModuleManager Protocol
    
    func isApplicable(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> Bool {
        // 文件操作模块对所有文件类型都适用
        return true
    }
    
    func menuItems(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 根据菜单类型和选中项目类型构建菜单
        if menuKind == .contextualMenuForItems {
            // 添加"新建文件"菜单组
            if items.count == 1 && fileTypes[0] == .directory {
                menuItems.append(newFileMenu(for: items[0]))
            }
            
            // 添加"发送到"菜单组
            menuItems.append(sendToMenu(for: items))
            
            // 添加"复制"菜单组
            menuItems.append(copyMenu(for: items))
            
            // 添加"剪切"菜单项
            let cutItem = NSMenuItem(title: "剪切", action: #selector(cutFiles(_:)), keyEquivalent: "")
            cutItem.target = self
            cutItem.representedObject = items
            menuItems.append(cutItem)
            
            // 如果只选中了一个文件，添加"根据文件名新建文件夹"菜单项
            if items.count == 1 && fileTypes[0] != .directory {
                let newFolderItem = NSMenuItem(title: "根据文件名新建文件夹", action: #selector(createFolderFromFileName(_:)), keyEquivalent: "")
                newFolderItem.target = self
                newFolderItem.representedObject = items[0]
                menuItems.append(newFolderItem)
            }
        } else if menuKind == .contextualMenuForContainer {
            // 添加"新建文件"菜单组
            if let containerURL = FIFinderSyncController.default().targetedURL() {
                menuItems.append(newFileMenu(for: containerURL))
            }
            
            // 添加"粘贴"菜单项，如果剪切板中有文件
            if hasCutFiles() {
                let pasteItem = NSMenuItem(title: "粘贴", action: #selector(pasteFiles(_:)), keyEquivalent: "")
                pasteItem.target = self
                menuItems.append(pasteItem)
            }
        }
        
        return menuItems
    }
    
    // MARK: - Menu Building Methods
    
    /// 创建"新建文件"子菜单
    private func newFileMenu(for directory: URL) -> NSMenuItem {
        let menu = NSMenu(title: "新建文件")
        
        // 按类别组织模板
        let categories = Dictionary(grouping: fileTemplates) { $0.category }
        
        // 按字母顺序排序类别
        let sortedCategories = categories.keys.sorted()
        
        for category in sortedCategories {
            if let templates = categories[category] {
                // 添加类别标题
                let categoryItem = NSMenuItem(title: category, action: nil, keyEquivalent: "")
                categoryItem.isEnabled = false
                menu.addItem(categoryItem)
                
                // 添加该类别下的所有模板
                for template in templates.sorted(by: { $0.name < $1.name }) {
                    let item = NSMenuItem(title: template.name, action: #selector(createNewFile(_:)), keyEquivalent: "")
                    item.target = self
                    if let iconName = template.iconName, let image = NSImage(systemSymbolName: iconName, accessibilityDescription: nil) {
                        item.image = image
                    }
                    item.representedObject = ["directory": directory, "template": template]
                    menu.addItem(item)
                }
                
                // 如果不是最后一个类别，添加分隔线
                if category != sortedCategories.last {
                    menu.addItem(NSMenuItem.separator())
                }
            }
        }
        
        // 添加"更多模板..."项
        menu.addItem(NSMenuItem.separator())
        let moreItem = NSMenuItem(title: "更多模板...", action: #selector(openTemplateSettings(_:)), keyEquivalent: "")
        moreItem.target = self
        menu.addItem(moreItem)
        
        let menuItem = NSMenuItem(title: "新建文件", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建"发送到"子菜单
    private func sendToMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "发送到")
        
        // 添加系统目录
        let desktopItem = NSMenuItem(title: "桌面", action: #selector(sendToLocation(_:)), keyEquivalent: "")
        desktopItem.target = self
        desktopItem.representedObject = ["items": items, "target": FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Desktop"), "operation": "copy"]
        menu.addItem(desktopItem)
        
        let documentsItem = NSMenuItem(title: "文档", action: #selector(sendToLocation(_:)), keyEquivalent: "")
        documentsItem.target = self
        documentsItem.representedObject = ["items": items, "target": FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Documents"), "operation": "copy"]
        menu.addItem(documentsItem)
        
        let downloadsItem = NSMenuItem(title: "下载", action: #selector(sendToLocation(_:)), keyEquivalent: "")
        downloadsItem.target = self
        downloadsItem.representedObject = ["items": items, "target": FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads"), "operation": "copy"]
        menu.addItem(downloadsItem)
        
        // 添加收藏的目录
        if !favoriteDirectories.isEmpty {
            menu.addItem(NSMenuItem.separator())
            
            for directory in favoriteDirectories {
                let item = NSMenuItem(title: directory.lastPathComponent, action: #selector(sendToLocation(_:)), keyEquivalent: "")
                item.target = self
                item.representedObject = ["items": items, "target": directory, "operation": "copy"]
                menu.addItem(item)
            }
        }
        
        // 添加复制/移动切换子菜单
        menu.addItem(NSMenuItem.separator())
        
        let copySubmenu = NSMenu(title: "复制到")
        let moveSubmenu = NSMenu(title: "移动到")
        
        let copyLabel = NSMenuItem(title: "复制到：", action: nil, keyEquivalent: "")
        copyLabel.isEnabled = false
        copySubmenu.addItem(copyLabel)
        
        let moveLabel = NSMenuItem(title: "移动到：", action: nil, keyEquivalent: "")
        moveLabel.isEnabled = false
        moveSubmenu.addItem(moveLabel)
        
        // 添加系统目录到复制/移动子菜单
        let copyToDesktop = NSMenuItem(title: "桌面", action: #selector(sendToLocation(_:)), keyEquivalent: "")
        copyToDesktop.target = self
        copyToDesktop.representedObject = ["items": items, "target": FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Desktop"), "operation": "copy"]
        copySubmenu.addItem(copyToDesktop)
        
        let moveToDesktop = NSMenuItem(title: "桌面", action: #selector(sendToLocation(_:)), keyEquivalent: "")
        moveToDesktop.target = self
        moveToDesktop.representedObject = ["items": items, "target": FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Desktop"), "operation": "move"]
        moveSubmenu.addItem(moveToDesktop)
        
        // ... 其他系统目录
        
        // 添加收藏的目录到复制/移动子菜单
        if !favoriteDirectories.isEmpty {
            copySubmenu.addItem(NSMenuItem.separator())
            moveSubmenu.addItem(NSMenuItem.separator())
            
            for directory in favoriteDirectories {
                let copyItem = NSMenuItem(title: directory.lastPathComponent, action: #selector(sendToLocation(_:)), keyEquivalent: "")
                copyItem.target = self
                copyItem.representedObject = ["items": items, "target": directory, "operation": "copy"]
                copySubmenu.addItem(copyItem)
                
                let moveItem = NSMenuItem(title: directory.lastPathComponent, action: #selector(sendToLocation(_:)), keyEquivalent: "")
                moveItem.target = self
                moveItem.representedObject = ["items": items, "target": directory, "operation": "move"]
                moveSubmenu.addItem(moveItem)
            }
        }
        
        // 添加"浏览..."选项
        copySubmenu.addItem(NSMenuItem.separator())
        moveSubmenu.addItem(NSMenuItem.separator())
        
        let browseCopyItem = NSMenuItem(title: "浏览...", action: #selector(browseAndSendTo(_:)), keyEquivalent: "")
        browseCopyItem.target = self
        browseCopyItem.representedObject = ["items": items, "operation": "copy"]
        copySubmenu.addItem(browseCopyItem)
        
        let browseMoveItem = NSMenuItem(title: "浏览...", action: #selector(browseAndSendTo(_:)), keyEquivalent: "")
        browseMoveItem.target = self
        browseMoveItem.representedObject = ["items": items, "operation": "move"]
        moveSubmenu.addItem(browseMoveItem)
        
        // 添加复制/移动子菜单
        let copyItem = NSMenuItem(title: "复制到", action: nil, keyEquivalent: "")
        copyItem.submenu = copySubmenu
        menu.addItem(copyItem)
        
        let moveItem = NSMenuItem(title: "移动到", action: nil, keyEquivalent: "")
        moveItem.submenu = moveSubmenu
        menu.addItem(moveItem)
        
        // 添加"管理目标..."选项
        menu.addItem(NSMenuItem.separator())
        let manageItem = NSMenuItem(title: "管理目标...", action: #selector(manageDestinations(_:)), keyEquivalent: "")
        manageItem.target = self
        menu.addItem(manageItem)
        
        let menuItem = NSMenuItem(title: "发送到", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建"复制"子菜单
    private func copyMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "复制")
        
        if items.count == 1 {
            // 复制文件名（不带扩展名）
            let nameWithoutExtItem = NSMenuItem(title: "复制文件名（不带扩展名）", action: #selector(copyNameWithoutExtension(_:)), keyEquivalent: "")
            nameWithoutExtItem.target = self
            nameWithoutExtItem.representedObject = items[0]
            menu.addItem(nameWithoutExtItem)
            
            // 复制文件名（带扩展名）
            let nameWithExtItem = NSMenuItem(title: "复制文件名（带扩展名）", action: #selector(copyNameWithExtension(_:)), keyEquivalent: "")
            nameWithExtItem.target = self
            nameWithExtItem.representedObject = items[0]
            menu.addItem(nameWithExtItem)
            
            menu.addItem(NSMenuItem.separator())
            
            // 复制文件路径
            let pathItem = NSMenuItem(title: "复制文件路径", action: #selector(copyPath(_:)), keyEquivalent: "")
            pathItem.target = self
            pathItem.representedObject = items[0]
            menu.addItem(pathItem)
            
            // 复制父目录路径
            let parentPathItem = NSMenuItem(title: "复制父目录路径", action: #selector(copyParentPath(_:)), keyEquivalent: "")
            parentPathItem.target = self
            parentPathItem.representedObject = items[0]
            menu.addItem(parentPathItem)
        } else {
            // 复制文件名（多文件）
            let namesItem = NSMenuItem(title: "复制所有文件名", action: #selector(copyMultipleNames(_:)), keyEquivalent: "")
            namesItem.target = self
            namesItem.representedObject = items
            menu.addItem(namesItem)
            
            // 复制文件路径（多文件）
            let pathsItem = NSMenuItem(title: "复制所有文件路径", action: #selector(copyMultiplePaths(_:)), keyEquivalent: "")
            pathsItem.target = self
            pathsItem.representedObject = items
            menu.addItem(pathsItem)
        }
        
        let menuItem = NSMenuItem(title: "复制", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    // MARK: - Action Methods
    
    @objc private func createNewFile(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let directory = info["directory"] as? URL,
              let template = info["template"] as? FileTemplate else {
            return
        }
        
        // 获取文件名
        let fileName = template.name
        
        // 检查文件是否已存在
        let fileURL = directory.appendingPathComponent(fileName)
        if FileManager.default.fileExists(atPath: fileURL.path) {
            // 如果文件已存在，生成一个新名称
            var newName = fileName
            var counter = 1
            var fileNameComponents = fileName.components(separatedBy: ".")
            let ext = fileNameComponents.count > 1 ? fileNameComponents.removeLast() : ""
            let baseFileName = fileNameComponents.joined(separator: ".")
            
            repeat {
                newName = "\(baseFileName) \(counter).\(ext)"
                fileURL = directory.appendingPathComponent(newName)
                counter += 1
            } while FileManager.default.fileExists(atPath: fileURL.path)
        }
        
        // 创建文件
        let fileContent = template.content.data(using: .utf8)
        if FileHelper.createFile(in: directory, named: fileURL.lastPathComponent, content: fileContent) != nil {
            // 刷新Finder显示
            FIFinderSyncController.default().requestBadgeIdentifier(forURL: directory)
        }
    }
    
    @objc private func openTemplateSettings(_ sender: NSMenuItem) {
        // 通知主应用打开模板设置
        let url = URL(string: "macrightplus://open-template-settings")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func sendToLocation(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let items = info["items"] as? [URL],
              let target = info["target"] as? URL,
              let operation = info["operation"] as? String else {
            return
        }
        
        // 检查目标目录是否存在，如果不存在则创建
        if !FileManager.default.fileExists(atPath: target.path) {
            do {
                try FileManager.default.createDirectory(at: target, withIntermediateDirectories: true)
            } catch {
                NSLog("Error creating directory: \(error)")
                return
            }
        }
        
        // 根据操作类型执行复制或移动
        for item in items {
            if operation == "copy" {
                _ = FileHelper.copyFile(from: item, to: target, overwrite: false)
            } else if operation == "move" {
                _ = FileHelper.moveFile(from: item, to: target, overwrite: false)
            }
        }
        
        // 刷新Finder显示
        FIFinderSyncController.default().requestBadgeIdentifier(forURL: target)
    }
    
    @objc private func browseAndSendTo(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let items = info["items"] as? [URL],
              let operation = info["operation"] as? String else {
            return
        }
        
        // 通知主应用打开文件选择器
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://browse-destination?items=\(itemPaths)&operation=\(operation)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func manageDestinations(_ sender: NSMenuItem) {
        // 通知主应用打开目标管理
        let url = URL(string: "macrightplus://manage-destinations")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func copyNameWithoutExtension(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        // 获取文件名（不带扩展名）
        var fileName = url.lastPathComponent
        if let dotIndex = fileName.lastIndex(of: ".") {
            fileName = String(fileName[..<dotIndex])
        }
        
        // 复制到剪贴板
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(fileName, forType: .string)
    }
    
    @objc private func copyNameWithExtension(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        // 获取文件名（带扩展名）
        let fileName = url.lastPathComponent
        
        // 复制到剪贴板
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(fileName, forType: .string)
    }
    
    @objc private func copyPath(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        // 复制文件路径到剪贴板
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(url.path, forType: .string)
    }
    
    @objc private func copyParentPath(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        // 获取父目录路径
        let parentPath = url.deletingLastPathComponent().path
        
        // 复制到剪贴板
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(parentPath, forType: .string)
    }
    
    @objc private func copyMultipleNames(_ sender: NSMenuItem) {
        guard let urls = sender.representedObject as? [URL] else {
            return
        }
        
        // 获取所有文件名
        let fileNames = urls.map { $0.lastPathComponent }
        let joinedNames = fileNames.joined(separator: "\n")
        
        // 复制到剪贴板
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(joinedNames, forType: .string)
    }
    
    @objc private func copyMultiplePaths(_ sender: NSMenuItem) {
        guard let urls = sender.representedObject as? [URL] else {
            return
        }
        
        // 获取所有文件路径
        let paths = urls.map { $0.path }
        let joinedPaths = paths.joined(separator: "\n")
        
        // 复制到剪贴板
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(joinedPaths, forType: .string)
    }
    
    @objc private func cutFiles(_ sender: NSMenuItem) {
        guard let urls = sender.representedObject as? [URL] else {
            return
        }
        
        // 保存剪切的文件路径到UserDefaults
        let paths = urls.map { $0.path }
        UserDefaults.shared.set(paths, forKey: "CutFiles")
        
        // 可选：设置文件的半透明显示效果
        if UserDefaults.shared.bool(forKey: "ShowCutFilesTransparent") {
            for url in urls {
                // 实现半透明效果的逻辑
                // 注意：这需要重写文件的扩展属性或使用其他技术
                // 这里仅作为占位，实际实现可能需要更复杂的代码
            }
        }
    }
    
    @objc private func pasteFiles(_ sender: NSMenuItem) {
        guard let paths = UserDefaults.shared.array(forKey: "CutFiles") as? [String],
              let targetURL = FIFinderSyncController.default().targetedURL() else {
            return
        }
        
        let urls = paths.map { URL(fileURLWithPath: $0) }
        
        // 移动文件到目标位置
        for url in urls {
            _ = FileHelper.moveFile(from: url, to: targetURL, overwrite: false)
        }
        
        // 清除剪切文件记录
        UserDefaults.shared.removeObject(forKey: "CutFiles")
        
        // 刷新Finder显示
        FIFinderSyncController.default().requestBadgeIdentifier(forURL: targetURL)
    }
    
    @objc private func createFolderFromFileName(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else {
            return
        }
        
        // 获取文件名（不带扩展名）
        var folderName = url.lastPathComponent
        if let dotIndex = folderName.lastIndex(of: ".") {
            folderName = String(folderName[..<dotIndex])
        }
        
        // 创建与文件同名的文件夹
        let parentURL = url.deletingLastPathComponent()
        let folderURL = parentURL.appendingPathComponent(folderName)
        
        // 检查文件夹是否已存在
        if FileManager.default.fileExists(atPath: folderURL.path) {
            // 如果文件夹已存在，生成一个新名称
            var newName = folderName
            var counter = 1
            
            repeat {
                newName = "\(folderName) \(counter)"
                folderURL = parentURL.appendingPathComponent(newName)
                counter += 1
            } while FileManager.default.fileExists(atPath: folderURL.path)
        }
        
        // 创建文件夹
        do {
            try FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: false)
            
            // 移动文件到新文件夹
            _ = FileHelper.moveFile(from: url, to: folderURL, overwrite: false)
            
            // 刷新Finder显示
            FIFinderSyncController.default().requestBadgeIdentifier(forURL: parentURL)
        } catch {
            NSLog("Error creating folder: \(error)")
        }
    }
    
    // MARK: - Helper Methods
    
    /// 检查是否有剪切的文件
    private func hasCutFiles() -> Bool {
        // 检查是否存在剪切的文件
        return UserDefaults.shared.array(forKey: "CutFiles") != nil
    }
}

/// 文件模板结构
struct FileTemplate: Codable {
    let name: String
    let iconName: String?
    let category: String
    let content: String
} 
import Cocoa
import FinderSync

class FinderSync: FIFinderSync {
    
    // MARK: - Properties
    
    private let finderSyncController = FIFinderSyncController.default()
    private let menuBuilder = MenuBuilder()
    
    // MARK: - Lifecycle
    
    override init() {
        super.init()
        
        NSLog("MacRightPlus Finder Extension: initializing")
        
        // 设置要监控的目录
        let directories = UserDefaults.shared.observedDirectories
        if directories.isEmpty {
            // 默认监控所有目录
            finderSyncController.directoryURLs = [URL(fileURLWithPath: "/")]
        } else {
            finderSyncController.directoryURLs = Set(directories.map { URL(fileURLWithPath: $0) })
        }
        
        // 注册通知，以便在设置变更时更新
        DistributedNotificationCenter.default().addObserver(
            self, 
            selector: #selector(settingsChanged(_:)),
            name: Notification.Name("com.macrightplus.settingsChanged"), 
            object: nil
        )
        
        NSLog("MacRightPlus Finder Extension: initialized with directories: \(finderSyncController.directoryURLs)")
    }
    
    deinit {
        DistributedNotificationCenter.default().removeObserver(self)
    }
    
    // MARK: - FIFinderSync
    
    // 当用户右键点击文件或文件夹时调用
    override func menu(for menuKind: FIMenuKind) -> NSMenu? {
        // 获取当前选中的项目
        let selectedItems = finderSyncController.selectedItemURLs() ?? []
        
        // 如果没有选中项目则返回nil
        guard !selectedItems.isEmpty else {
            return nil
        }
        
        // 使用MenuBuilder构建菜单
        let contextMenu = menuBuilder.buildMenu(for: selectedItems, menuKind: menuKind)
        
        return contextMenu
    }
    
    // MARK: - Private methods
    
    @objc private func settingsChanged(_ notification: Notification) {
        NSLog("MacRightPlus Finder Extension: settings changed")
        
        // 更新监控的目录
        let directories = UserDefaults.shared.observedDirectories
        if directories.isEmpty {
            finderSyncController.directoryURLs = [URL(fileURLWithPath: "/")]
        } else {
            finderSyncController.directoryURLs = Set(directories.map { URL(fileURLWithPath: $0) })
        }
        
        // 清除菜单缓存
        menuBuilder.clearCache()
    }
} 
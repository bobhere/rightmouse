import Cocoa
import FinderSync

/// 图片工具管理器，提供图片转换、处理等功能
class ImageToolsManager: ModuleManager {
    
    // MARK: - Properties
    
    var moduleTitle: String {
        return "图片工具"
    }
    
    // 支持的图片格式
    private let supportedImageFormats = ["jpg", "jpeg", "png", "gif", "tiff", "bmp", "heic", "webp", "svg"]
    
    // MARK: - ModuleManager Protocol
    
    func isApplicable(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> Bool {
        // 检查是否选中了图片文件
        for fileType in fileTypes {
            if fileType == .image {
                return true
            }
        }
        
        // 检查文件扩展名是否是支持的图片格式
        for url in items {
            if supportedImageFormats.contains(url.pathExtension.lowercased()) {
                return true
            }
        }
        
        return false
    }
    
    func menuItems(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 仅处理选中项目的菜单
        if menuKind == .contextualMenuForItems {
            // 添加图片尺寸调整菜单
            menuItems.append(resizeMenu(for: items))
            
            // 添加格式转换菜单
            menuItems.append(convertMenu(for: items))
            
            // 添加图标生成菜单
            menuItems.append(iconMenu(for: items))
            
            // 添加图片信息菜单项
            let infoItem = NSMenuItem(title: "查看图片信息", action: #selector(showImageInfo(_:)), keyEquivalent: "")
            infoItem.target = self
            infoItem.representedObject = items
            menuItems.append(infoItem)
        }
        
        return menuItems
    }
    
    // MARK: - Menu Building Methods
    
    /// 创建尺寸调整子菜单
    private func resizeMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "调整尺寸")
        
        // 预设尺寸选项
        let presets: [(name: String, size: CGSize)] = [
            ("小缩略图 (128x128)", CGSize(width: 128, height: 128)),
            ("中缩略图 (256x256)", CGSize(width: 256, height: 256)),
            ("大缩略图 (512x512)", CGSize(width: 512, height: 512)),
            ("社交媒体图片 (1200x630)", CGSize(width: 1200, height: 630)),
            ("高清 (1920x1080)", CGSize(width: 1920, height: 1080)),
            ("4K (3840x2160)", CGSize(width: 3840, height: 2160))
        ]
        
        for preset in presets {
            let item = NSMenuItem(title: preset.name, action: #selector(resizeImage(_:)), keyEquivalent: "")
            item.target = self
            item.representedObject = ["items": items, "width": preset.size.width, "height": preset.size.height, "keepAspectRatio": true]
            menu.addItem(item)
        }
        
        menu.addItem(NSMenuItem.separator())
        
        // 自定义尺寸选项
        let customItem = NSMenuItem(title: "自定义尺寸...", action: #selector(customResize(_:)), keyEquivalent: "")
        customItem.target = self
        customItem.representedObject = items
        menu.addItem(customItem)
        
        // 按百分比缩放选项
        let scaleSubmenu = NSMenu(title: "按百分比缩放")
        let scales = [25, 50, 75, 90, 125, 150, 200]
        
        for scale in scales {
            let item = NSMenuItem(title: "\(scale)%", action: #selector(scaleImage(_:)), keyEquivalent: "")
            item.target = self
            item.representedObject = ["items": items, "scale": scale]
            scaleSubmenu.addItem(item)
        }
        
        let scaleItem = NSMenuItem(title: "按百分比缩放", action: nil, keyEquivalent: "")
        scaleItem.submenu = scaleSubmenu
        menu.addItem(scaleItem)
        
        let menuItem = NSMenuItem(title: "调整尺寸", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建格式转换子菜单
    private func convertMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "转换格式")
        
        // 格式选项
        let formats = ["JPEG", "PNG", "TIFF", "BMP", "GIF", "WEBP", "HEIC"]
        
        for format in formats {
            let item = NSMenuItem(title: "转换为\(format)", action: #selector(convertFormat(_:)), keyEquivalent: "")
            item.target = self
            item.representedObject = ["items": items, "format": format.lowercased()]
            menu.addItem(item)
        }
        
        // 批量转换选项
        if items.count > 1 {
            menu.addItem(NSMenuItem.separator())
            
            let batchItem = NSMenuItem(title: "批量转换...", action: #selector(batchConvert(_:)), keyEquivalent: "")
            batchItem.target = self
            batchItem.representedObject = items
            menu.addItem(batchItem)
        }
        
        let menuItem = NSMenuItem(title: "转换格式", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建图标生成子菜单
    private func iconMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "生成图标")
        
        // macOS图标选项
        let macosItem = NSMenuItem(title: "生成macOS图标(.icns)", action: #selector(createMacOSIcon(_:)), keyEquivalent: "")
        macosItem.target = self
        macosItem.representedObject = items
        menu.addItem(macosItem)
        
        // iOS图标选项
        let iosItem = NSMenuItem(title: "生成iOS图标集", action: #selector(createIOSIconSet(_:)), keyEquivalent: "")
        iosItem.target = self
        iosItem.representedObject = items
        menu.addItem(iosItem)
        
        // 网站图标选项
        let faviconItem = NSMenuItem(title: "生成网站图标(favicon)", action: #selector(createFavicon(_:)), keyEquivalent: "")
        faviconItem.target = self
        faviconItem.representedObject = items
        menu.addItem(faviconItem)
        
        // 自定义图标选项
        menu.addItem(NSMenuItem.separator())
        let customItem = NSMenuItem(title: "自定义图标尺寸...", action: #selector(createCustomIconSet(_:)), keyEquivalent: "")
        customItem.target = self
        customItem.representedObject = items
        menu.addItem(customItem)
        
        let menuItem = NSMenuItem(title: "生成图标", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    // MARK: - Action Methods
    
    @objc private func resizeImage(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let items = info["items"] as? [URL],
              let width = info["width"] as? CGFloat,
              let height = info["height"] as? CGFloat,
              let keepAspectRatio = info["keepAspectRatio"] as? Bool else {
            return
        }
        
        // 构建参数并通知主应用进行图片调整
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        var urlComponents = URLComponents(string: "macrightplus://resize-image")!
        urlComponents.queryItems = [
            URLQueryItem(name: "paths", value: itemPaths),
            URLQueryItem(name: "width", value: "\(Int(width))"),
            URLQueryItem(name: "height", value: "\(Int(height))"),
            URLQueryItem(name: "keepAspectRatio", value: "\(keepAspectRatio)")
        ]
        
        if let url = urlComponents.url {
            NSWorkspace.shared.open(url)
        }
    }
    
    @objc private func customResize(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else {
            return
        }
        
        // 构建参数并通知主应用打开自定义尺寸对话框
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://custom-resize?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func scaleImage(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let items = info["items"] as? [URL],
              let scale = info["scale"] as? Int else {
            return
        }
        
        // 构建参数并通知主应用进行图片缩放
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://scale-image?paths=\(itemPaths)&scale=\(scale)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func convertFormat(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let items = info["items"] as? [URL],
              let format = info["format"] as? String else {
            return
        }
        
        // 构建参数并通知主应用进行格式转换
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-format?paths=\(itemPaths)&format=\(format)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func batchConvert(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else {
            return
        }
        
        // 构建参数并通知主应用打开批量转换对话框
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://batch-convert?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func createMacOSIcon(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else {
            return
        }
        
        // 对单张图片进行处理
        if items.count == 1 {
            let url = items[0]
            let targetURL = URL(string: "macrightplus://create-macos-icon?path=\(url.path)")!
            NSWorkspace.shared.open(targetURL)
        } else {
            // 弹出提示，每次只能处理一张图片
            showAlert(title: "无法创建图标", message: "每次只能选择一张图片来创建图标")
        }
    }
    
    @objc private func createIOSIconSet(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else {
            return
        }
        
        // 对单张图片进行处理
        if items.count == 1 {
            let url = items[0]
            let targetURL = URL(string: "macrightplus://create-ios-iconset?path=\(url.path)")!
            NSWorkspace.shared.open(targetURL)
        } else {
            // 弹出提示，每次只能处理一张图片
            showAlert(title: "无法创建图标", message: "每次只能选择一张图片来创建图标")
        }
    }
    
    @objc private func createFavicon(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else {
            return
        }
        
        // 对单张图片进行处理
        if items.count == 1 {
            let url = items[0]
            let targetURL = URL(string: "macrightplus://create-favicon?path=\(url.path)")!
            NSWorkspace.shared.open(targetURL)
        } else {
            // 弹出提示，每次只能处理一张图片
            showAlert(title: "无法创建图标", message: "每次只能选择一张图片来创建图标")
        }
    }
    
    @objc private func createCustomIconSet(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else {
            return
        }
        
        // 对单张图片进行处理
        if items.count == 1 {
            let url = items[0]
            let targetURL = URL(string: "macrightplus://create-custom-icon?path=\(url.path)")!
            NSWorkspace.shared.open(targetURL)
        } else {
            // 弹出提示，每次只能处理一张图片
            showAlert(title: "无法创建图标", message: "每次只能选择一张图片来创建图标")
        }
    }
    
    @objc private func showImageInfo(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else {
            return
        }
        
        // 对单张图片进行处理
        if items.count == 1 {
            let url = items[0]
            let targetURL = URL(string: "macrightplus://show-image-info?path=\(url.path)")!
            NSWorkspace.shared.open(targetURL)
        } else {
            // 弹出提示，每次只能处理一张图片
            showAlert(title: "无法查看图片信息", message: "每次只能选择一张图片来查看详细信息")
        }
    }
    
    // MARK: - Helper Methods
    
    /// 显示提示对话框
    private func showAlert(title: String, message: String) {
        // 在Finder扩展中不能直接显示警告，需要通知主应用
        let encodedMessage = message.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? message
        let encodedTitle = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? title
        let url = URL(string: "macrightplus://show-alert?title=\(encodedTitle)&message=\(encodedMessage)")!
        NSWorkspace.shared.open(url)
    }
} 
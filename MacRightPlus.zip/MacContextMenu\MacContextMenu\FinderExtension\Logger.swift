import Foundation
import os.log

/// 日志级别枚举
enum LogLevel: Int {
    case off = 0
    case error = 1
    case warning = 2
    case info = 3
    case debug = 4
    
    /// 从UserDefaults中获取日志级别
    static var current: LogLevel {
        let level = UserDefaults.shared.integer(forKey: "LogLevel")
        return LogLevel(rawValue: level) ?? .info
    }
}

/// 日志类，提供日志记录功能
class Logger {
    /// 单例实例
    static let shared = Logger()
    
    /// 日志分类
    private enum Category: String {
        case general = "General"
        case fileOps = "FileOperations"
        case devTools = "DeveloperTools"
        case imageTools = "ImageTools"
        case docTools = "DocumentTools"
        case mediaTools = "MediaTools"
        case securityTools = "SecurityTools"
        case networkTools = "NetworkTools"
        case customScript = "CustomScript"
        case menuBuilder = "MenuBuilder"
        case finderSync = "FinderSync"
    }
    
    /// 底层日志记录器字典
    private var loggers: [Category: OSLog] = [:]
    
    private init() {
        // 初始化各种分类的日志记录器
        for category in [
            Category.general, .fileOps, .devTools, .imageTools,
            .docTools, .mediaTools, .securityTools, .networkTools,
            .customScript, .menuBuilder, .finderSync
        ] {
            loggers[category] = OSLog(subsystem: "com.macrightplus.MacContextMenu", category: category.rawValue)
        }
    }
    
    // MARK: - 日志记录方法
    
    /// 记录调试级别日志
    /// - Parameters:
    ///   - message: 日志消息
    ///   - category: 日志分类
    ///   - function: 调用函数名
    ///   - file: 调用文件名
    ///   - line: 调用行号
    static func debug(_ message: String, category: String = "General", function: String = #function, file: String = #file, line: Int = #line) {
        guard LogLevel.current.rawValue >= LogLevel.debug.rawValue else { return }
        
        let categoryEnum = Category(rawValue: category) ?? .general
        let logger = shared.loggers[categoryEnum] ?? shared.loggers[.general]!
        
        let fileName = URL(fileURLWithPath: file).lastPathComponent
        let logMessage = "[\(fileName):\(line)] \(function) - \(message)"
        
        os_log("%{public}@", log: logger, type: .debug, logMessage)
    }
    
    /// 记录信息级别日志
    /// - Parameters:
    ///   - message: 日志消息
    ///   - category: 日志分类
    static func info(_ message: String, category: String = "General") {
        guard LogLevel.current.rawValue >= LogLevel.info.rawValue else { return }
        
        let categoryEnum = Category(rawValue: category) ?? .general
        let logger = shared.loggers[categoryEnum] ?? shared.loggers[.general]!
        
        os_log("%{public}@", log: logger, type: .info, message)
    }
    
    /// 记录警告级别日志
    /// - Parameters:
    ///   - message: 日志消息
    ///   - category: 日志分类
    static func warning(_ message: String, category: String = "General") {
        guard LogLevel.current.rawValue >= LogLevel.warning.rawValue else { return }
        
        let categoryEnum = Category(rawValue: category) ?? .general
        let logger = shared.loggers[categoryEnum] ?? shared.loggers[.general]!
        
        os_log("%{public}@", log: logger, type: .default, "⚠️ \(message)")
    }
    
    /// 记录错误级别日志
    /// - Parameters:
    ///   - message: 日志消息
    ///   - category: 日志分类
    ///   - error: 错误对象
    static func error(_ message: String, error: Error? = nil, category: String = "General") {
        guard LogLevel.current.rawValue >= LogLevel.error.rawValue else { return }
        
        let categoryEnum = Category(rawValue: category) ?? .general
        let logger = shared.loggers[categoryEnum] ?? shared.loggers[.general]!
        
        if let error = error {
            os_log("%{public}@: %{public}@", log: logger, type: .error, message, error.localizedDescription)
        } else {
            os_log("%{public}@", log: logger, type: .error, message)
        }
    }
} 
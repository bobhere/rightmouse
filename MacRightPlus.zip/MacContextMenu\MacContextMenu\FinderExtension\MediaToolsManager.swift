import Cocoa
import FinderSync

/// 媒体工具管理器，提供音频和视频文件处理功能
class MediaToolsManager: ModuleManager {
    
    // MARK: - Properties
    
    var moduleTitle: String {
        return "媒体工具"
    }
    
    // 支持的音频格式
    private let supportedAudioFormats = ["mp3", "wav", "m4a", "flac", "aac", "ogg", "wma", "aiff", "alac"]
    
    // 支持的视频格式
    private let supportedVideoFormats = ["mp4", "mov", "avi", "mkv", "wmv", "flv", "webm", "m4v", "3gp", "ts"]
    
    // MARK: - ModuleManager Protocol
    
    func isApplicable(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> Bool {
        // 检查是否选中了媒体文件
        for fileType in fileTypes {
            if fileType == .audio || fileType == .video {
                return true
            }
        }
        
        // 检查文件扩展名是否是支持的媒体格式
        for url in items {
            let ext = url.pathExtension.lowercased()
            if supportedAudioFormats.contains(ext) || supportedVideoFormats.contains(ext) {
                return true
            }
        }
        
        return false
    }
    
    func menuItems(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 仅处理选中项目的菜单
        if menuKind == .contextualMenuForItems {
            // 按类型分类文件
            let audioFiles = items.filter { supportedAudioFormats.contains($0.pathExtension.lowercased()) }
            let videoFiles = items.filter { supportedVideoFormats.contains($0.pathExtension.lowercased()) }
            
            // 添加音频处理菜单
            if !audioFiles.isEmpty {
                menuItems.append(audioMenu(for: audioFiles))
            }
            
            // 添加视频处理菜单
            if !videoFiles.isEmpty {
                menuItems.append(videoMenu(for: videoFiles))
            }
            
            // 添加通用媒体操作菜单
            if !items.isEmpty {
                menuItems.append(commonMediaMenu(for: items))
            }
        }
        
        return menuItems
    }
    
    // MARK: - Menu Building Methods
    
    /// 创建音频工具子菜单
    private func audioMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "音频工具")
        
        // 添加格式转换选项
        let convertSubmenu = NSMenu(title: "转换格式")
        
        for format in ["MP3", "WAV", "M4A", "FLAC", "AAC"] {
            let item = NSMenuItem(title: "转换为\(format)", action: #selector(convertAudioFormat(_:)), keyEquivalent: "")
            item.target = self
            item.representedObject = ["items": items, "format": format.lowercased()]
            convertSubmenu.addItem(item)
        }
        
        let convertItem = NSMenuItem(title: "转换格式", action: nil, keyEquivalent: "")
        convertItem.submenu = convertSubmenu
        menu.addItem(convertItem)
        
        // 音频增强选项
        menu.addItem(NSMenuItem.separator())
        
        let enhanceItem = NSMenuItem(title: "音频增强", action: #selector(enhanceAudio(_:)), keyEquivalent: "")
        enhanceItem.target = self
        enhanceItem.representedObject = items
        menu.addItem(enhanceItem)
        
        // 音频编辑选项
        let trimItem = NSMenuItem(title: "剪辑音频", action: #selector(trimAudio(_:)), keyEquivalent: "")
        trimItem.target = self
        trimItem.representedObject = items
        menu.addItem(trimItem)
        
        if items.count == 1 {
            let extractItem = NSMenuItem(title: "提取音频片段", action: #selector(extractAudioSegment(_:)), keyEquivalent: "")
            extractItem.target = self
            extractItem.representedObject = items[0]
            menu.addItem(extractItem)
            
            let normalizeItem = NSMenuItem(title: "音量标准化", action: #selector(normalizeAudio(_:)), keyEquivalent: "")
            normalizeItem.target = self
            normalizeItem.representedObject = items[0]
            menu.addItem(normalizeItem)
            
            // 获取音频信息
            menu.addItem(NSMenuItem.separator())
            let infoItem = NSMenuItem(title: "查看音频信息", action: #selector(showAudioInfo(_:)), keyEquivalent: "")
            infoItem.target = self
            infoItem.representedObject = items[0]
            menu.addItem(infoItem)
        }
        
        if items.count > 1 {
            menu.addItem(NSMenuItem.separator())
            
            let mergeItem = NSMenuItem(title: "合并音频文件", action: #selector(mergeAudioFiles(_:)), keyEquivalent: "")
            mergeItem.target = self
            mergeItem.representedObject = items
            menu.addItem(mergeItem)
            
            let batchItem = NSMenuItem(title: "批量处理", action: #selector(batchProcessAudio(_:)), keyEquivalent: "")
            batchItem.target = self
            batchItem.representedObject = items
            menu.addItem(batchItem)
        }
        
        let menuItem = NSMenuItem(title: "音频工具", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建视频工具子菜单
    private func videoMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "视频工具")
        
        // 添加格式转换选项
        let convertSubmenu = NSMenu(title: "转换格式")
        
        for format in ["MP4", "MOV", "MKV", "AVI", "WEBM"] {
            let item = NSMenuItem(title: "转换为\(format)", action: #selector(convertVideoFormat(_:)), keyEquivalent: "")
            item.target = self
            item.representedObject = ["items": items, "format": format.lowercased()]
            convertSubmenu.addItem(item)
        }
        
        let convertItem = NSMenuItem(title: "转换格式", action: nil, keyEquivalent: "")
        convertItem.submenu = convertSubmenu
        menu.addItem(convertItem)
        
        // 压缩选项
        menu.addItem(NSMenuItem.separator())
        
        let compressItem = NSMenuItem(title: "压缩视频", action: #selector(compressVideo(_:)), keyEquivalent: "")
        compressItem.target = self
        compressItem.representedObject = items
        menu.addItem(compressItem)
        
        // 视频编辑选项
        if items.count == 1 {
            let trimItem = NSMenuItem(title: "剪辑视频", action: #selector(trimVideo(_:)), keyEquivalent: "")
            trimItem.target = self
            trimItem.representedObject = items[0]
            menu.addItem(trimItem)
            
            let extractFrameItem = NSMenuItem(title: "提取视频帧", action: #selector(extractVideoFrame(_:)), keyEquivalent: "")
            extractFrameItem.target = self
            extractFrameItem.representedObject = items[0]
            menu.addItem(extractFrameItem)
            
            let extractAudioItem = NSMenuItem(title: "提取音频", action: #selector(extractAudioFromVideo(_:)), keyEquivalent: "")
            extractAudioItem.target = self
            extractAudioItem.representedObject = items[0]
            menu.addItem(extractAudioItem)
            
            let resizeItem = NSMenuItem(title: "调整分辨率", action: #selector(resizeVideo(_:)), keyEquivalent: "")
            resizeItem.target = self
            resizeItem.representedObject = items[0]
            menu.addItem(resizeItem)
            
            // 获取视频信息
            menu.addItem(NSMenuItem.separator())
            let infoItem = NSMenuItem(title: "查看视频信息", action: #selector(showVideoInfo(_:)), keyEquivalent: "")
            infoItem.target = self
            infoItem.representedObject = items[0]
            menu.addItem(infoItem)
        }
        
        if items.count > 1 {
            menu.addItem(NSMenuItem.separator())
            
            let concatItem = NSMenuItem(title: "连接视频", action: #selector(concatenateVideos(_:)), keyEquivalent: "")
            concatItem.target = self
            concatItem.representedObject = items
            menu.addItem(concatItem)
            
            let batchItem = NSMenuItem(title: "批量处理", action: #selector(batchProcessVideo(_:)), keyEquivalent: "")
            batchItem.target = self
            batchItem.representedObject = items
            menu.addItem(batchItem)
        }
        
        let menuItem = NSMenuItem(title: "视频工具", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建通用媒体工具子菜单
    private func commonMediaMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "通用媒体工具")
        
        // 添加元数据编辑选项
        let metadataItem = NSMenuItem(title: "编辑元数据", action: #selector(editMediaMetadata(_:)), keyEquivalent: "")
        metadataItem.target = self
        metadataItem.representedObject = items
        menu.addItem(metadataItem)
        
        // 添加播放列表选项
        if items.count > 1 {
            let playlistItem = NSMenuItem(title: "创建播放列表", action: #selector(createPlaylist(_:)), keyEquivalent: "")
            playlistItem.target = self
            playlistItem.representedObject = items
            menu.addItem(playlistItem)
        }
        
        // 添加预览选项
        if items.count == 1 {
            let previewItem = NSMenuItem(title: "快速预览", action: #selector(quickPreviewMedia(_:)), keyEquivalent: "")
            previewItem.target = self
            previewItem.representedObject = items[0]
            menu.addItem(previewItem)
        }
        
        let menuItem = NSMenuItem(title: "通用媒体工具", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    // MARK: - Action Methods
    
    // 音频格式转换
    
    @objc private func convertAudioFormat(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let items = info["items"] as? [URL],
              let format = info["format"] as? String else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-audio?paths=\(itemPaths)&format=\(format)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func enhanceAudio(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://enhance-audio?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func trimAudio(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://trim-audio?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func extractAudioSegment(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://extract-audio-segment?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func normalizeAudio(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://normalize-audio?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func showAudioInfo(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://show-audio-info?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func mergeAudioFiles(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://merge-audio?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func batchProcessAudio(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://batch-process-audio?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    // 视频处理
    
    @objc private func convertVideoFormat(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let items = info["items"] as? [URL],
              let format = info["format"] as? String else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://convert-video?paths=\(itemPaths)&format=\(format)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func compressVideo(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://compress-video?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func trimVideo(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://trim-video?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func extractVideoFrame(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://extract-video-frame?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func extractAudioFromVideo(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://extract-audio-from-video?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func resizeVideo(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://resize-video?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func showVideoInfo(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://show-video-info?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func concatenateVideos(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://concatenate-videos?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func batchProcessVideo(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://batch-process-video?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    // 通用媒体操作
    
    @objc private func editMediaMetadata(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://edit-media-metadata?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func createPlaylist(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://create-playlist?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func quickPreviewMedia(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://quick-preview-media?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    // MARK: - Helper Methods
    
    /// 显示提示对话框
    private func showAlert(title: String, message: String) {
        // 在Finder扩展中不能直接显示警告，需要通知主应用
        let encodedMessage = message.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? message
        let encodedTitle = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? title
        let url = URL(string: "macrightplus://show-alert?title=\(encodedTitle)&message=\(encodedMessage)")!
        NSWorkspace.shared.open(url)
    }
} 
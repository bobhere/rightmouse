import Cocoa
import FinderSync

class MenuBuilder {
    
    // MARK: - Properties
    
    // 菜单缓存，以提高性能
    private var menuCache: [String: NSMenu] = [:]
    
    // 模块管理器字典，每个模块负责一类功能
    private lazy var moduleManagers: [String: ModuleManager] = {
        return [
            "file": FileOperationsManager(),
            "developer": DeveloperToolsManager(),
            "image": ImageToolsManager(),
            "document": DocumentToolsManager(),
            "media": MediaToolsManager(),
            "security": SecurityToolsManager(),
            "network": NetworkToolsManager(),
            "custom": CustomScriptManager()
        ]
    }()
    
    // MARK: - Public methods
    
    /// 为选定的项目构建上下文菜单
    /// - Parameters:
    ///   - items: 选中的文件/文件夹URL数组
    ///   - menuKind: 菜单类型(背景、选中项等)
    /// - Returns: 构建好的NSMenu
    func buildMenu(for items: [URL], menuKind: FIMenuKind) -> NSMenu {
        // 创建缓存键
        let cacheKey = createCacheKey(for: items, menuKind: menuKind)
        
        // 如果缓存中有，直接返回
        if let cachedMenu = menuCache[cacheKey] {
            return cachedMenu
        }
        
        // 创建主菜单
        let menu = NSMenu(title: "MacRightPlus")
        
        // 获取已启用的模块
        let enabledModules = UserDefaults.shared.enabledModules
        
        // 获取文件类型信息，用于上下文感知
        let fileTypes = items.map { FileHelper.getFileType(for: $0) }
        
        // 添加菜单标题
        let titleItem = NSMenuItem(title: "MacRightPlus", action: nil, keyEquivalent: "")
        titleItem.image = NSImage(named: "MenuIcon")
        menu.addItem(titleItem)
        menu.addItem(NSMenuItem.separator())
        
        // 根据启用的模块和文件类型添加菜单项
        for module in enabledModules {
            if let manager = moduleManagers[module] {
                // 检查模块是否适用于当前选择的文件
                if manager.isApplicable(for: items, fileTypes: fileTypes, menuKind: menuKind) {
                    // 获取该模块的菜单项
                    let moduleItems = manager.menuItems(for: items, fileTypes: fileTypes, menuKind: menuKind)
                    
                    // 如果有菜单项，添加分隔线和模块项
                    if !moduleItems.isEmpty {
                        // 如果不是第一个模块，添加分隔线
                        if menu.items.count > 2 {
                            menu.addItem(NSMenuItem.separator())
                        }
                        
                        // 添加模块标题
                        let moduleTitle = NSMenuItem(title: manager.moduleTitle, action: nil, keyEquivalent: "")
                        moduleTitle.isEnabled = false
                        menu.addItem(moduleTitle)
                        
                        // 添加该模块的菜单项
                        for item in moduleItems {
                            menu.addItem(item)
                        }
                    }
                }
            }
        }
        
        // 添加"设置"菜单项
        menu.addItem(NSMenuItem.separator())
        let settingsItem = NSMenuItem(title: "设置...", action: #selector(openSettings), keyEquivalent: ",")
        settingsItem.target = self
        menu.addItem(settingsItem)
        
        // 缓存并返回菜单
        menuCache[cacheKey] = menu
        return menu
    }
    
    /// 清除菜单缓存
    func clearCache() {
        menuCache.removeAll()
    }
    
    // MARK: - Private methods
    
    /// 创建用于缓存的唯一键
    private func createCacheKey(for items: [URL], menuKind: FIMenuKind) -> String {
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        return "\(menuKind.rawValue)_\(itemPaths)"
    }
    
    /// 打开设置窗口
    @objc private func openSettings() {
        // 向主应用发送打开设置的请求
        let url = URL(string: "macrightplus://open-settings")!
        NSWorkspace.shared.open(url)
    }
} 
import Cocoa
import FinderSync

/// 模块管理器协议，所有功能模块都必须实现这个协议
protocol ModuleManager {
    /// 模块名称
    var moduleTitle: String { get }
    
    /// 检查模块是否适用于当前选择的文件
    /// - Parameters:
    ///   - items: 选中的文件/文件夹URL数组
    ///   - fileTypes: 文件类型数组，与items一一对应
    ///   - menuKind: 菜单类型
    /// - Returns: 如果适用返回true，否则返回false
    func isApplicable(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> Bool
    
    /// 获取模块的菜单项
    /// - Parameters:
    ///   - items: 选中的文件/文件夹URL数组
    ///   - fileTypes: 文件类型数组，与items一一对应
    ///   - menuKind: 菜单类型
    /// - Returns: 菜单项数组
    func menuItems(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> [NSMenuItem]
}

/// 文件类型枚举
enum FileType {
    case directory
    case image
    case audio
    case video
    case document
    case code
    case archive
    case executable
    case unknown
    
    /// 根据文件扩展名判断文件类型
    static func from(extension ext: String) -> FileType {
        let ext = ext.lowercased()
        
        // 图片文件
        if ["jpg", "jpeg", "png", "gif", "tiff", "bmp", "heic", "webp", "svg"].contains(ext) {
            return .image
        }
        
        // 音频文件
        if ["mp3", "wav", "m4a", "flac", "aac", "ogg", "wma"].contains(ext) {
            return .audio
        }
        
        // 视频文件
        if ["mp4", "mov", "avi", "mkv", "wmv", "flv", "webm"].contains(ext) {
            return .video
        }
        
        // 文档文件
        if ["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "md", "pages", "numbers", "key"].contains(ext) {
            return .document
        }
        
        // 代码文件
        if ["swift", "m", "h", "c", "cpp", "hpp", "java", "py", "js", "html", "css", "php", "rb", "go", "rs", "ts", "json", "xml", "yml"].contains(ext) {
            return .code
        }
        
        // 压缩文件
        if ["zip", "rar", "7z", "tar", "gz", "bz2", "xz", "dmg"].contains(ext) {
            return .archive
        }
        
        // 可执行文件
        if ["app", "exe", "sh", "command", "bin"].contains(ext) {
            return .executable
        }
        
        return .unknown
    }
}

/// UserDefaults扩展，提供共享的UserDefaults实例
extension UserDefaults {
    /// 共享的UserDefaults实例，用于在主应用和扩展之间共享数据
    static var shared: UserDefaults {
        // 替换为你的App Group标识符
        return UserDefaults(suiteName: "group.com.macrightplus.shared") ?? .standard
    }
    
    /// 获取启用的模块列表
    var enabledModules: [String] {
        return array(forKey: "EnabledModules") as? [String] ?? ["file", "developer", "image", "document", "media", "security", "network", "custom"]
    }
    
    /// 获取监控的目录列表
    var observedDirectories: [String] {
        return array(forKey: "ObservedDirectories") as? [String] ?? []
    }
} 
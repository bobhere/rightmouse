import Cocoa
import FinderSync

/// 网络工具管理器，提供分享、上传、远程操作等功能
class NetworkToolsManager: ModuleManager {
    
    // MARK: - Properties
    
    var moduleTitle: String {
        return "网络工具"
    }
    
    // 支持的图片文件类型，用于分享服务
    private let supportedImageFormats = ["jpg", "jpeg", "png", "gif", "tiff", "bmp", "heic", "webp"]
    
    // 支持的文本文件类型，用于文本工具
    private let supportedTextFormats = ["txt", "md", "rtf", "html", "json", "xml", "csv", "yml", "yaml"]
    
    // 云服务配置
    private var configuredCloudServices: [CloudService] {
        guard let data = UserDefaults.shared.data(forKey: "ConfiguredCloudServices"),
              let services = try? JSONDecoder().decode([CloudService].self, from: data) else {
            // 返回默认配置的云服务
            return defaultCloudServices
        }
        return services
    }
    
    // 默认云服务
    private let defaultCloudServices: [CloudService] = [
        CloudService(id: "dropbox", name: "Dropbox", iconName: "icloud", isConfigured: false),
        CloudService(id: "googledrive", name: "Google Drive", iconName: "externaldrive", isConfigured: false),
        CloudService(id: "onedrive", name: "OneDrive", iconName: "network", isConfigured: false),
        CloudService(id: "icloud", name: "iCloud Drive", iconName: "icloud", isConfigured: true)
    ]
    
    // MARK: - ModuleManager Protocol
    
    func isApplicable(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> Bool {
        // 网络工具适用于所有类型的文件
        return !items.isEmpty
    }
    
    func menuItems(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 仅处理选中项目的菜单
        if menuKind == .contextualMenuForItems {
            // 添加分享菜单
            menuItems.append(shareMenu(for: items, fileTypes: fileTypes))
            
            // 添加云服务菜单
            menuItems.append(cloudServicesMenu(for: items))
            
            // 添加远程工具菜单
            menuItems.append(remoteToolsMenu(for: items))
            
            // 添加QR码生成菜单
            if items.count == 1 && (supportedTextFormats.contains(items[0].pathExtension.lowercased()) || fileTypes.contains(.document)) {
                menuItems.append(qrCodeMenu(for: items[0]))
            }
        }
        
        return menuItems
    }
    
    // MARK: - Menu Building Methods
    
    /// 创建分享子菜单
    private func shareMenu(for items: [URL], fileTypes: [FileType]) -> NSMenuItem {
        let menu = NSMenu(title: "分享")
        
        // 添加系统分享服务
        let shareServiceItem = NSMenuItem(title: "系统分享服务", action: #selector(systemShareService(_:)), keyEquivalent: "")
        shareServiceItem.target = self
        shareServiceItem.representedObject = items
        menu.addItem(shareServiceItem)
        
        menu.addItem(NSMenuItem.separator())
        
        // 添加邮件发送选项
        let emailItem = NSMenuItem(title: "通过邮件发送", action: #selector(emailFiles(_:)), keyEquivalent: "")
        emailItem.target = self
        emailItem.representedObject = items
        menu.addItem(emailItem)
        
        // 如果是图片文件，添加特殊分享选项
        let imageItems = items.filter { supportedImageFormats.contains($0.pathExtension.lowercased()) }
        if !imageItems.isEmpty {
            menu.addItem(NSMenuItem.separator())
            
            let instagramItem = NSMenuItem(title: "分享到Instagram", action: #selector(shareToInstagram(_:)), keyEquivalent: "")
            instagramItem.target = self
            instagramItem.representedObject = imageItems
            menu.addItem(instagramItem)
            
            let twitterItem = NSMenuItem(title: "分享到Twitter", action: #selector(shareToTwitter(_:)), keyEquivalent: "")
            twitterItem.target = self
            twitterItem.representedObject = imageItems
            menu.addItem(twitterItem)
        }
        
        let menuItem = NSMenuItem(title: "分享", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建云服务子菜单
    private func cloudServicesMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "云服务")
        
        // 获取已配置的云服务
        let services = configuredCloudServices
        
        // 添加上传选项
        for service in services {
            if service.isConfigured {
                let uploadItem = NSMenuItem(title: "上传到\(service.name)", action: #selector(uploadToCloud(_:)), keyEquivalent: "")
                uploadItem.target = self
                if let image = NSImage(systemSymbolName: service.iconName, accessibilityDescription: nil) {
                    uploadItem.image = image
                }
                uploadItem.representedObject = ["items": items, "service": service.id]
                menu.addItem(uploadItem)
            }
        }
        
        // 如果没有已配置的服务，显示提示
        if !services.contains(where: { $0.isConfigured }) {
            let noServiceItem = NSMenuItem(title: "没有已配置的云服务", action: nil, keyEquivalent: "")
            noServiceItem.isEnabled = false
            menu.addItem(noServiceItem)
        }
        
        // 添加配置云服务选项
        menu.addItem(NSMenuItem.separator())
        let configItem = NSMenuItem(title: "配置云服务...", action: #selector(configureCloudServices(_:)), keyEquivalent: "")
        configItem.target = self
        menu.addItem(configItem)
        
        let menuItem = NSMenuItem(title: "云服务", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建远程工具子菜单
    private func remoteToolsMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "远程工具")
        
        // 添加FTP上传选项
        let ftpItem = NSMenuItem(title: "FTP上传...", action: #selector(ftpUpload(_:)), keyEquivalent: "")
        ftpItem.target = self
        ftpItem.representedObject = items
        menu.addItem(ftpItem)
        
        // 添加SFTP上传选项
        let sftpItem = NSMenuItem(title: "SFTP上传...", action: #selector(sftpUpload(_:)), keyEquivalent: "")
        sftpItem.target = self
        sftpItem.representedObject = items
        menu.addItem(sftpItem)
        
        // 添加WebDAV上传选项
        let webdavItem = NSMenuItem(title: "WebDAV上传...", action: #selector(webdavUpload(_:)), keyEquivalent: "")
        webdavItem.target = self
        webdavItem.representedObject = items
        menu.addItem(webdavItem)
        
        menu.addItem(NSMenuItem.separator())
        
        // 添加SSH命令执行选项
        let sshItem = NSMenuItem(title: "远程SSH命令...", action: #selector(executeSSHCommand(_:)), keyEquivalent: "")
        sshItem.target = self
        sshItem.representedObject = items
        menu.addItem(sshItem)
        
        // 添加远程管理选项
        menu.addItem(NSMenuItem.separator())
        let manageItem = NSMenuItem(title: "管理远程连接...", action: #selector(manageRemoteConnections(_:)), keyEquivalent: "")
        manageItem.target = self
        menu.addItem(manageItem)
        
        let menuItem = NSMenuItem(title: "远程工具", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建QR码生成子菜单
    private func qrCodeMenu(for url: URL) -> NSMenuItem {
        let menu = NSMenu(title: "QR码工具")
        
        // 为文本文件添加"生成QR码"选项
        if supportedTextFormats.contains(url.pathExtension.lowercased()) {
            let fileContentsItem = NSMenuItem(title: "从文件内容生成QR码", action: #selector(generateQRCodeFromFileContents(_:)), keyEquivalent: "")
            fileContentsItem.target = self
            fileContentsItem.representedObject = url
            menu.addItem(fileContentsItem)
        }
        
        // 添加"从文件路径生成QR码"选项
        let filePathItem = NSMenuItem(title: "从文件路径生成QR码", action: #selector(generateQRCodeFromFilePath(_:)), keyEquivalent: "")
        filePathItem.target = self
        filePathItem.representedObject = url
        menu.addItem(filePathItem)
        
        // 添加"自定义QR码"选项
        menu.addItem(NSMenuItem.separator())
        let customItem = NSMenuItem(title: "创建自定义QR码...", action: #selector(createCustomQRCode(_:)), keyEquivalent: "")
        customItem.target = self
        customItem.representedObject = url
        menu.addItem(customItem)
        
        let menuItem = NSMenuItem(title: "QR码工具", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    // MARK: - Action Methods
    
    // 分享操作
    
    @objc private func systemShareService(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://system-share?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func emailFiles(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://email-files?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func shareToInstagram(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://share-instagram?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func shareToTwitter(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://share-twitter?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    // 云服务操作
    
    @objc private func uploadToCloud(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String: Any],
              let items = info["items"] as? [URL],
              let serviceId = info["service"] as? String else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://upload-cloud?paths=\(itemPaths)&service=\(serviceId)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func configureCloudServices(_ sender: NSMenuItem) {
        let url = URL(string: "macrightplus://configure-cloud-services")!
        NSWorkspace.shared.open(url)
    }
    
    // 远程工具操作
    
    @objc private func ftpUpload(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://ftp-upload?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func sftpUpload(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://sftp-upload?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func webdavUpload(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://webdav-upload?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func executeSSHCommand(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://ssh-command?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func manageRemoteConnections(_ sender: NSMenuItem) {
        let url = URL(string: "macrightplus://manage-remote-connections")!
        NSWorkspace.shared.open(url)
    }
    
    // QR码操作
    
    @objc private func generateQRCodeFromFileContents(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://qrcode-from-contents?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func generateQRCodeFromFilePath(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://qrcode-from-path?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    @objc private func createCustomQRCode(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://create-custom-qrcode?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    // MARK: - Helper Methods
    
    /// 显示提示对话框
    private func showAlert(title: String, message: String) {
        // 在Finder扩展中不能直接显示警告，需要通知主应用
        let encodedMessage = message.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? message
        let encodedTitle = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? title
        let url = URL(string: "macrightplus://show-alert?title=\(encodedTitle)&message=\(encodedMessage)")!
        NSWorkspace.shared.open(url)
    }
}

/// 云服务配置结构
struct CloudService: Codable {
    let id: String
    let name: String
    let iconName: String
    let isConfigured: Bool
} 
import Cocoa
import FinderSync

/// 安全工具管理器，提供文件加密、安全删除等功能
class SecurityToolsManager: ModuleManager {
    
    // MARK: - Properties
    
    var moduleTitle: String {
        return "安全工具"
    }
    
    // MARK: - ModuleManager Protocol
    
    func isApplicable(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> Bool {
        // 安全工具适用于所有类型的文件
        return !items.isEmpty
    }
    
    func menuItems(for items: [URL], fileTypes: [FileType], menuKind: FIMenuKind) -> [NSMenuItem] {
        var menuItems: [NSMenuItem] = []
        
        // 仅处理选中项目的菜单
        if menuKind == .contextualMenuForItems {
            // 加密/解密菜单
            menuItems.append(encryptionMenu(for: items))
            
            // 安全删除菜单
            menuItems.append(secureDeleteMenu(for: items))
            
            // 文件验证菜单
            menuItems.append(fileVerificationMenu(for: items))
            
            // 权限管理菜单
            menuItems.append(permissionsMenu(for: items, fileTypes: fileTypes))
        }
        
        return menuItems
    }
    
    // MARK: - Menu Building Methods
    
    /// 创建加密/解密子菜单
    private func encryptionMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "加密/解密")
        
        // 添加加密选项
        let encryptItem = NSMenuItem(title: "加密文件", action: #selector(encryptFiles(_:)), keyEquivalent: "")
        encryptItem.target = self
        encryptItem.representedObject = items
        menu.addItem(encryptItem)
        
        // 添加解密选项
        let decryptItem = NSMenuItem(title: "解密文件", action: #selector(decryptFiles(_:)), keyEquivalent: "")
        decryptItem.target = self
        decryptItem.representedObject = items
        menu.addItem(decryptItem)
        
        // 添加创建加密压缩文件选项
        if items.count > 0 {
            menu.addItem(NSMenuItem.separator())
            
            let encryptedZipItem = NSMenuItem(title: "创建加密ZIP", action: #selector(createEncryptedZip(_:)), keyEquivalent: "")
            encryptedZipItem.target = self
            encryptedZipItem.representedObject = items
            menu.addItem(encryptedZipItem)
        }
        
        let menuItem = NSMenuItem(title: "加密/解密", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建安全删除子菜单
    private func secureDeleteMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "安全删除")
        
        // 添加快速安全删除选项
        let quickDeleteItem = NSMenuItem(title: "快速安全删除", action: #selector(quickSecureDelete(_:)), keyEquivalent: "")
        quickDeleteItem.target = self
        quickDeleteItem.representedObject = items
        menu.addItem(quickDeleteItem)
        
        // 添加DOD标准删除选项
        let dodDeleteItem = NSMenuItem(title: "DOD标准删除（3次覆写）", action: #selector(dodSecureDelete(_:)), keyEquivalent: "")
        dodDeleteItem.target = self
        dodDeleteItem.representedObject = items
        menu.addItem(dodDeleteItem)
        
        // 添加古特曼标准删除选项
        let gutmannDeleteItem = NSMenuItem(title: "古特曼标准删除（35次覆写）", action: #selector(gutmannSecureDelete(_:)), keyEquivalent: "")
        gutmannDeleteItem.target = self
        gutmannDeleteItem.representedObject = items
        menu.addItem(gutmannDeleteItem)
        
        // 添加自定义安全删除选项
        menu.addItem(NSMenuItem.separator())
        let customDeleteItem = NSMenuItem(title: "自定义安全删除...", action: #selector(customSecureDelete(_:)), keyEquivalent: "")
        customDeleteItem.target = self
        customDeleteItem.representedObject = items
        menu.addItem(customDeleteItem)
        
        let menuItem = NSMenuItem(title: "安全删除", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建文件验证子菜单
    private func fileVerificationMenu(for items: [URL]) -> NSMenuItem {
        let menu = NSMenu(title: "文件验证")
        
        // 添加计算校验和选项
        let hashSubmenu = NSMenu(title: "计算校验和")
        
        let md5Item = NSMenuItem(title: "计算MD5", action: #selector(calculateMD5(_:)), keyEquivalent: "")
        md5Item.target = self
        md5Item.representedObject = items
        hashSubmenu.addItem(md5Item)
        
        let sha1Item = NSMenuItem(title: "计算SHA-1", action: #selector(calculateSHA1(_:)), keyEquivalent: "")
        sha1Item.target = self
        sha1Item.representedObject = items
        hashSubmenu.addItem(sha1Item)
        
        let sha256Item = NSMenuItem(title: "计算SHA-256", action: #selector(calculateSHA256(_:)), keyEquivalent: "")
        sha256Item.target = self
        sha256Item.representedObject = items
        hashSubmenu.addItem(sha256Item)
        
        let hashItem = NSMenuItem(title: "计算校验和", action: nil, keyEquivalent: "")
        hashItem.submenu = hashSubmenu
        menu.addItem(hashItem)
        
        // 添加比较文件选项
        if items.count == 2 {
            let compareItem = NSMenuItem(title: "比较文件", action: #selector(compareFiles(_:)), keyEquivalent: "")
            compareItem.target = self
            compareItem.representedObject = items
            menu.addItem(compareItem)
        }
        
        // 添加验证校验和选项
        let verifyItem = NSMenuItem(title: "验证校验和...", action: #selector(verifyChecksum(_:)), keyEquivalent: "")
        verifyItem.target = self
        verifyItem.representedObject = items
        menu.addItem(verifyItem)
        
        // 添加扫描恶意软件选项
        menu.addItem(NSMenuItem.separator())
        let scanItem = NSMenuItem(title: "扫描恶意软件", action: #selector(scanMalware(_:)), keyEquivalent: "")
        scanItem.target = self
        scanItem.representedObject = items
        menu.addItem(scanItem)
        
        let menuItem = NSMenuItem(title: "文件验证", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    /// 创建权限管理子菜单
    private func permissionsMenu(for items: [URL], fileTypes: [FileType]) -> NSMenuItem {
        let menu = NSMenu(title: "权限管理")
        
        // 添加设置权限选项
        let setPermissionsItem = NSMenuItem(title: "设置权限...", action: #selector(setPermissions(_:)), keyEquivalent: "")
        setPermissionsItem.target = self
        setPermissionsItem.representedObject = items
        menu.addItem(setPermissionsItem)
        
        // 添加获取权限信息选项
        let getPermissionsItem = NSMenuItem(title: "获取权限信息", action: #selector(getPermissionInfo(_:)), keyEquivalent: "")
        getPermissionsItem.target = self
        getPermissionsItem.representedObject = items
        menu.addItem(getPermissionsItem)
        
        // 添加递归设置权限选项
        if items.count == 1 && fileTypes[0] == .directory {
            menu.addItem(NSMenuItem.separator())
            
            let recursivePermissionsItem = NSMenuItem(title: "递归设置权限...", action: #selector(setRecursivePermissions(_:)), keyEquivalent: "")
            recursivePermissionsItem.target = self
            recursivePermissionsItem.representedObject = items[0]
            menu.addItem(recursivePermissionsItem)
        }
        
        let menuItem = NSMenuItem(title: "权限管理", action: nil, keyEquivalent: "")
        menuItem.submenu = menu
        return menuItem
    }
    
    // MARK: - Action Methods
    
    // 加密/解密操作
    
    @objc private func encryptFiles(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://encrypt-files?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func decryptFiles(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://decrypt-files?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func createEncryptedZip(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://create-encrypted-zip?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    // 安全删除操作
    
    @objc private func quickSecureDelete(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://quick-secure-delete?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func dodSecureDelete(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://dod-secure-delete?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func gutmannSecureDelete(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://gutmann-secure-delete?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func customSecureDelete(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://custom-secure-delete?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    // 文件验证操作
    
    @objc private func calculateMD5(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://calculate-md5?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func calculateSHA1(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://calculate-sha1?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func calculateSHA256(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://calculate-sha256?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func compareFiles(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL], items.count == 2 else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://compare-files?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func verifyChecksum(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://verify-checksum?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func scanMalware(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://scan-malware?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    // 权限管理操作
    
    @objc private func setPermissions(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://set-permissions?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func getPermissionInfo(_ sender: NSMenuItem) {
        guard let items = sender.representedObject as? [URL] else { return }
        
        let itemPaths = items.map { $0.path }.joined(separator: "|")
        let url = URL(string: "macrightplus://get-permissions?paths=\(itemPaths)")!
        NSWorkspace.shared.open(url)
    }
    
    @objc private func setRecursivePermissions(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? URL else { return }
        
        let targetURL = URL(string: "macrightplus://set-recursive-permissions?path=\(url.path)")!
        NSWorkspace.shared.open(targetURL)
    }
    
    // MARK: - Helper Methods
    
    /// 显示提示对话框
    private func showAlert(title: String, message: String) {
        // 在Finder扩展中不能直接显示警告，需要通知主应用
        let encodedMessage = message.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? message
        let encodedTitle = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? title
        let url = URL(string: "macrightplus://show-alert?title=\(encodedTitle)&message=\(encodedMessage)")!
        NSWorkspace.shared.open(url)
    }
} 
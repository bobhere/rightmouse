#!/bin/bash

# MacRightPlus - App Store提交自动化脚本
# 此脚本用于准备应用并上传到App Store Connect

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 配置变量
APP_VERSION="1.0.0"
BUILD_NUMBER=$(date +%Y%m%d%H%M)
PROJECT_PATH=$(pwd)
ARCHIVE_PATH="$PROJECT_PATH/build/MacRightPlus.xcarchive"
EXPORT_PATH="$PROJECT_PATH/build/export"

# 打印使用说明
function print_usage() {
    echo -e "\n${BLUE}MacRightPlus App Store提交工具${NC}"
    echo -e "用法: $0 [选项]"
    echo -e "选项:"
    echo -e "  -c, --clean     清理构建目录"
    echo -e "  -b, --build     只构建应用"
    echo -e "  -a, --archive   构建并创建归档文件"
    echo -e "  -u, --upload    上传到App Store Connect"
    echo -e "  -h, --help      显示帮助信息"
    echo -e "\n示例: $0 --clean --archive --upload\n"
}

# 清理构建目录
function clean_build() {
    echo -e "${BLUE}清理构建目录...${NC}"
    
    # 使用xcodebuild清理
    xcodebuild clean -project MacContextMenu.xcodeproj -scheme MacContextMenu -configuration Release
    
    # 移除旧的构建目录
    rm -rf build/
    
    echo -e "${GREEN}清理完成${NC}"
}

# 更新版本号
function update_version() {
    echo -e "${BLUE}更新版本号...${NC}"
    
    # 更新Info.plist中的版本号
    /usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $APP_VERSION" "MacContextMenu/Info.plist"
    /usr/libexec/PlistBuddy -c "Set :CFBundleVersion $BUILD_NUMBER" "MacContextMenu/Info.plist"
    /usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $APP_VERSION" "MacContextMenu/FinderExtension/Info.plist"
    /usr/libexec/PlistBuddy -c "Set :CFBundleVersion $BUILD_NUMBER" "MacContextMenu/FinderExtension/Info.plist"
    
    echo -e "${GREEN}版本已更新为 $APP_VERSION ($BUILD_NUMBER)${NC}"
}

# 构建应用
function build_app() {
    echo -e "${BLUE}构建应用...${NC}"
    
    # 使用xcodebuild构建
    xcodebuild build -project MacContextMenu.xcodeproj -scheme MacContextMenu -configuration Release
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}构建成功${NC}"
    else
        echo -e "${RED}构建失败${NC}"
        exit 1
    fi
}

# 创建归档文件
function create_archive() {
    echo -e "${BLUE}创建归档文件...${NC}"
    
    # 创建构建目录
    mkdir -p "$(dirname "$ARCHIVE_PATH")"
    
    # 创建归档文件
    xcodebuild archive -project MacContextMenu.xcodeproj -scheme MacContextMenu -configuration Release -archivePath "$ARCHIVE_PATH"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}归档创建成功: $ARCHIVE_PATH${NC}"
    else
        echo -e "${RED}归档创建失败${NC}"
        exit 1
    fi
}

# 导出应用
function export_app() {
    echo -e "${BLUE}导出应用...${NC}"
    
    # 创建导出选项plist
    cat > exportOptions.plist << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>app-store</string>
    <key>teamID</key>
    <string>YOUR_TEAM_ID</string>
    <key>uploadBitcode</key>
    <false/>
    <key>uploadSymbols</key>
    <true/>
</dict>
</plist>
EOF
    
    # 导出应用
    xcodebuild -exportArchive -archivePath "$ARCHIVE_PATH" -exportPath "$EXPORT_PATH" -exportOptionsPlist exportOptions.plist
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}应用导出成功: $EXPORT_PATH${NC}"
    else
        echo -e "${RED}应用导出失败${NC}"
        exit 1
    fi
    
    # 清理临时文件
    rm exportOptions.plist
}

# 上传到App Store Connect
function upload_to_appstore() {
    echo -e "${BLUE}上传到App Store Connect...${NC}"
    
    # 查找导出的.app文件
    APP_PATH=$(find "$EXPORT_PATH" -name "*.app" -maxdepth 1)
    
    if [ -z "$APP_PATH" ]; then
        echo -e "${RED}错误: 找不到导出的.app文件${NC}"
        exit 1
    fi
    
    # 使用xcrun上传
    xcrun altool --upload-app --type macos --file "$APP_PATH" --username "YOUR_APPLE_ID" --password "@keychain:APP_STORE_CONNECT_PASSWORD"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}上传成功！应用已提交到App Store Connect${NC}"
    else
        echo -e "${RED}上传失败${NC}"
        exit 1
    fi
}

# 验证应用
function validate_app() {
    echo -e "${BLUE}验证应用...${NC}"
    
    # 验证归档文件
    xcrun altool --validate-app --type macos --file "$EXPORT_PATH/MacRightPlus.app" --username "YOUR_APPLE_ID" --password "@keychain:APP_STORE_CONNECT_PASSWORD"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}应用验证通过${NC}"
    else
        echo -e "${RED}应用验证失败${NC}"
        exit 1
    fi
}

# 主函数
function main() {
    # 处理命令行参数
    if [ $# -eq 0 ]; then
        print_usage
        exit 0
    fi
    
    CLEAN=false
    BUILD=false
    ARCHIVE=false
    UPLOAD=false
    
    while [ "$1" != "" ]; do
        case $1 in
            -c | --clean)
                CLEAN=true
                ;;
            -b | --build)
                BUILD=true
                ;;
            -a | --archive)
                ARCHIVE=true
                ;;
            -u | --upload)
                UPLOAD=true
                ;;
            -h | --help)
                print_usage
                exit 0
                ;;
            *)
                echo -e "${RED}未知选项: $1${NC}"
                print_usage
                exit 1
                ;;
        esac
        shift
    done
    
    # 执行选定的操作
    if [ "$CLEAN" = true ]; then
        clean_build
    fi
    
    update_version
    
    if [ "$BUILD" = true ]; then
        build_app
    fi
    
    if [ "$ARCHIVE" = true ]; then
        create_archive
        export_app
    fi
    
    if [ "$UPLOAD" = true ]; then
        validate_app
        upload_to_appstore
    fi
    
    echo -e "\n${GREEN}完成！${NC}"
}

# 执行主函数
main "$@" 
#!/bin/bash

# MacRightPlus模块测试脚本
# 此脚本创建测试文件并验证各个模块的功能

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 测试目录
TEST_DIR="$HOME/MacRightPlusTest"

# 日志文件
LOG_FILE="$TEST_DIR/test_results.log"

# 创建测试目录
function setup_test_environment() {
    echo -e "${BLUE}正在设置测试环境...${NC}"
    
    # 创建测试目录
    mkdir -p "$TEST_DIR"
    mkdir -p "$TEST_DIR/Images"
    mkdir -p "$TEST_DIR/Documents"
    mkdir -p "$TEST_DIR/Media"
    mkdir -p "$TEST_DIR/Code"
    
    # 记录到日志
    echo "$(date): 测试环境设置完成" > "$LOG_FILE"
    echo "测试目录: $TEST_DIR" >> "$LOG_FILE"
    
    echo -e "${GREEN}测试环境设置完成${NC}"
}

# 创建测试文件
function create_test_files() {
    echo -e "${BLUE}创建测试文件...${NC}"
    
    # 创建图像文件
    convert -size 800x600 gradient:blue-red "$TEST_DIR/Images/test.jpg"
    convert -size 800x600 gradient:green-yellow "$TEST_DIR/Images/test.png"
    
    # 创建文本文档
    echo "这是一个测试文档" > "$TEST_DIR/Documents/test.txt"
    echo "# Markdown测试" > "$TEST_DIR/Documents/test.md"
    
    # 创建代码文件
    echo 'print("Hello, World!")' > "$TEST_DIR/Code/test.py"
    echo 'console.log("Hello, World!");' > "$TEST_DIR/Code/test.js"
    echo '#include <iostream>\nint main() {\n  std::cout << "Hello, World!" << std::endl;\n  return 0;\n}' > "$TEST_DIR/Code/test.cpp"
    echo 'import Foundation\nprint("Hello, World!")' > "$TEST_DIR/Code/test.swift"
    
    # 记录到日志
    echo "$(date): 测试文件创建完成" >> "$LOG_FILE"
    ls -la "$TEST_DIR" >> "$LOG_FILE"
    
    echo -e "${GREEN}测试文件创建完成${NC}"
}

# 验证应用安装
function verify_app_installation() {
    echo -e "${BLUE}验证应用安装...${NC}"
    
    # 检查应用是否安装
    if [ -d "/Applications/MacRightPlus.app" ]; then
        echo -e "${GREEN}MacRightPlus已安装${NC}"
        echo "$(date): MacRightPlus已安装" >> "$LOG_FILE"
    else
        echo -e "${RED}MacRightPlus未安装${NC}"
        echo "$(date): MacRightPlus未安装" >> "$LOG_FILE"
        exit 1
    fi
    
    # 检查扩展是否启用
    # 注意：这个检查可能需要更复杂的方法，因为扩展状态不能直接从命令行检查
    echo -e "${YELLOW}请手动确认Finder扩展是否已启用（系统偏好设置 > 扩展）${NC}"
    echo "$(date): 提示用户确认扩展是否启用" >> "$LOG_FILE"
}

# 设置日志级别
function enable_debug_logging() {
    echo -e "${BLUE}启用调试日志...${NC}"
    
    # 设置日志级别为debug
    defaults write com.macrightplus.MacContextMenu LogLevel -int 4
    
    echo -e "${GREEN}调试日志已启用${NC}"
    echo "$(date): 调试日志已启用" >> "$LOG_FILE"
}

# 启动Finder以激活扩展
function restart_finder() {
    echo -e "${BLUE}重启Finder...${NC}"
    
    killall Finder
    
    echo -e "${GREEN}Finder已重启${NC}"
    echo "$(date): Finder已重启" >> "$LOG_FILE"
}

# 打印测试说明
function print_test_instructions() {
    echo -e "\n${YELLOW}=== MacRightPlus测试说明 ===${NC}"
    echo -e "${YELLOW}1. 在Finder中导航到测试目录: ${BLUE}$TEST_DIR${NC}"
    echo -e "${YELLOW}2. 右键点击不同的测试文件，验证上下文菜单中的MacRightPlus选项${NC}"
    echo -e "${YELLOW}3. 验证以下模块功能:${NC}"
    echo -e "   ${BLUE}- 文件操作${NC}: 右键点击任意文件"
    echo -e "   ${BLUE}- 开发者工具${NC}: 右键点击代码文件夹或代码文件"
    echo -e "   ${BLUE}- 图像工具${NC}: 右键点击图像文件"
    echo -e "   ${BLUE}- 文档工具${NC}: 右键点击文档文件"
    echo -e "   ${BLUE}- 媒体工具${NC}: 右键点击媒体文件"
    echo -e "   ${BLUE}- 安全工具${NC}: 右键点击任意文件"
    echo -e "   ${BLUE}- 网络工具${NC}: 右键点击任意文件"
    echo -e "   ${BLUE}- 自定义脚本${NC}: 确认自定义脚本功能"
    echo -e "${YELLOW}4. 测试结果记录在: ${BLUE}$LOG_FILE${NC}\n"
}

# 主函数
function main() {
    echo -e "${BLUE}=== MacRightPlus模块测试 ===${NC}\n"
    
    setup_test_environment
    create_test_files
    verify_app_installation
    enable_debug_logging
    restart_finder
    print_test_instructions
    
    echo -e "\n${GREEN}测试环境准备完成，请按照说明进行手动测试${NC}"
}

# 执行主函数
main 